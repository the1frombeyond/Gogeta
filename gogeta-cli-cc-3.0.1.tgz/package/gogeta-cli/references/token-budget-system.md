# Token Budget & Context Management System

## 📊 Token Budget System

### Overview
GOGETA CLI implements a proactive token budget system to prevent context overflow and optimize costs.

### Budget Allocation (Max 40% Context)
```
Tier 1 (Always Loaded): ~6K tokens
- ROADMAP.md
- STATE.md  
- CL AUDE.md

Tier 2 (Load on Demand): ~10K tokens
- few-shot-examples/
- Specific rules/*.md files
- Context.md (if referenced)

Tier 3 (NEVER Auto-Load): 100KB+
- AGENTS.md
- workflows/
- references/ (except this file)
```

### Token Tracking
```javascript
// Per-task token budget
const tokenBudget = {
  perTask: contextLimit * 0.4 / totalTasks,
  currentUsage: getCurrentTokens(),
  remaining: function() { 
    return this.perTask - this.currentUsage; 
  }
};

// Proactive compaction check
if (tokenBudget.remaining() < tokenBudget.perTask * 0.2) {
  // Less than 20% left - compact proactively!
  compactAndSaveCheckpoint();
}
```

## 🔄 Proactive Compaction

### When to Compact
```bash
# Check token usage BEFORE it's too late
CURRENT_TOKENS=$(get_current_token_count)
CONTEXT_LIMIT=$(get_context_limit)  # e.g., 200K

if [ $(echo "$CURRENT_TOKENS * 100 / $CONTEXT_LIMIT" | bc) -gt 40 ]; then
  echo "⚠️ Token usage at 40% - creating checkpoint before compaction..."
  
  # SAVE CHECKPOINT FIRST
  node -e "
    const checkpoint = {
      phase: '$PHASE',
      plan: '$PLAN',
      completedTasks: $(get_completed_tasks),
      currentTask: $(get_current_task),
      commitHashes: $(get_commit_hashes),
      tokenCount: $CURRENT_TOKENS,
      timestamp: '$(date -u +"%Y-%m-%dT%H:%M:%SZ")'
    };
    require('fs').writeFileSync('.planning/CHECKPOINT.json', 
    JSON.stringify(checkpoint, null, 2));
  "
  
  echo "✓ Checkpoint saved to .planning/CHECKPOINT.json"
  
  # NOW compact safely
  compactContext();
fi
```

### Checkpoint File Structure
```json
{
  "phase": "1",
  "plan": "auth",
  "completedTasks": [1, 2, 3],
  "currentTask": 4,
  "commitHashes": ["abc1234", "def5678"],
  "tokenCount": 45000,
  "timestamp": "2026-04-28T15:30:00Z",
  "filesModified": ["src/auth.js", "src/types/user.ts"],
  "nextSteps": "Implement JWT refresh token logic"
}
```

## 💾 Checkpoint Files

### Purpose
Checkpoint files ensure NO work is lost when /compact or /clear is run.

### Auto-Save Triggers
1. **Token usage >40%** → Save checkpoint, then compact
2. **Before /compact command** → Force checkpoint save
3. **Before /clear command** → Force checkpoint save
4. **Task completion** → Update checkpoint with commit hash

### Checkpoint Recovery
```bash
# After /compact or /clear, agent checks:
if [ -f ".planning/CHECKPOINT.json" ]; then
  echo "📂 Found checkpoint - resuming from:"
  cat .planning/CHECKPOINT.json | jq '.currentTask'
  
  # Resume from saved state
  resumeFromCheckpoint();
fi
```

## 📚 Tiered Docs Loading

### Strategy (Max 40% Context)
```javascript
// Tier 1: Always load (lightweight, ~6K tokens)
const tier1 = ['ROADMAP.md', 'STATE.md', 'CLAUDE.md'];

// Tier 2: Load only if needed (medium, ~10K tokens)
const needsExamples = taskDescription.includes('example');
if (needsExamples) loadFile('few-shot-examples/');

// Tier 3: NEVER auto-load (heavy, 100KB+)
// AGENTS.md, workflows/, references/ - load manually if needed

// Enforce 40% max context
if (getTotalContextTokens() > contextLimit * 0.4) {
  pruneIrrelevantContext();
}
```

### Benefits
- **Faster loads**: Only load what's needed
- **Lower costs**: Less tokens = lower API costs
- **Better focus**: No irrelevant context pollution
- **Scales better**: Works with 200K+ context windows

## ✂️ Relevance-Based Pruning

### Rules (Max 40%, Never Prune System Prompts/Errors)
```javascript
function pruneIrrelevantContext() {
  const keepPatterns = [
    /system.*prompt/i,
    /error/i,
    /fail/i,
    /bug/i,
    /critical/i
  ];
  
  const allContext = getAllContext();
  const pruned = allContext.filter(item => {
    // NEVER prune system prompts
    if (item.type === 'system') return true;
    // NEVER prune errors
    if (keepPatterns.some(p => p.test(item.content))) return true;
    // Prune if irrelevant to current task
    return isRelevantToTask(item, currentTask);
  });
  
  // Ensure we're under 40%
  if (pruned.length < allContext.length) {
    console.log(`✂️ Pruned ${allContext.length - pruned.length} irrelevant items`);
    setContext(pruned);
  }
}
```

### Pruning Criteria
**ALWAYS KEEP:**
- System prompts (NEVER prune)
- Error messages (NEVER prune)
- Current task context
- Recent commits/checkpoints
- Project configuration

**MAY PRUNE:**
- Old conversation history
- Completed task details
- Documentation not relevant to current task
- Example files from other features

## 💰 Cost/ROI Tracking

### Per-Developer Tracking
```bash
# Track token usage for ROI calculation
echo "$PHASE,$PLAN,$(date +%s),$CURRENT_TOKENS" >> .planning/TOKEN_USAGE.csv

# Calculate ROI (tokens saved vs traditional approach)
TRADITIONAL_APPROACH=150000  # estimated tokens without GOGETA
TOKENS_SAVED=$(echo "$TRADITIONAL_APPROACH - $CURRENT_TOKENS" | bc)
ROI=$(echo "$TOKENS_SAVED * 100 / $TRADITIONAL_APPROACH" | bc)
echo "💰 ROI: Saved $TOKENS_SAVED tokens ($ROI% reduction)"
```

### ROI Calculation
```javascript
const traditionalTokens = 150000; // estimated without GOGETA
const gogetaTokens = getCurrentTokenCount();
const saved = traditionalTokens - gogetaTokens;
const roi = (saved / traditionalTokens) * 100;

console.log(`💰 ROI: Saved ${saved} tokens (${roi.toFixed(1)}% reduction)`);
```

### Token Usage CSV Format
```csv
phase,plan,timestamp,tokens,description
1,auth,1714300800,45000,Auth implementation
1,auth,1714301200,52000,Added JWT refresh
2,payments,1714302000,38000,Payment gateway integration
```

## 📊 A/B Telemetry

### Measuring Real Savings
```javascript
// A/B test: GOGETA vs Traditional approach
const experiment = {
  group: Math.random() > 0.5 ? 'gogeta' : 'traditional',
  phase: currentPhase,
  tokensUsed: getCurrentTokenCount(),
  timeSpent: getElapsedTime(),
  success: checkSuccessCriteria()
};

// Log for analysis
logTelemetry(experiment);
```

### Telemetry Events
```javascript
// Event: token_budget_exceeded
trackEvent('token_budget_exceeded', {
  phase: 'auth',
  tokenCount: 85000,
  threshold: 80000,
  action: 'checkpoint_saved'
});

// Event: context_pruned
trackEvent('context_pruned', {
  itemsPruned: 15,
  reason: 'irrelevant_to_task',
  tokensSaved: 12000
});

// Event: checkpoint_used
trackEvent('checkpoint_used', {
  phase: 'auth',
  tasksRecovered: 3,
  timeSaved: '45s'
});
```

## 🎯 Usage Examples

### Example 1: Proactive Compaction
```bash
# Agent notices token usage at 42%
echo "⚠️ Token usage at 42% - creating checkpoint..."

# Save checkpoint
node -e "require('fs').writeFileSync('.planning/CHECKPOINT.json', 
  JSON.stringify({ phase: '1', plan: 'auth', ... }))"

# Compact safely
compactContext();
echo "✅ Compacted! Token usage now at 15%"
```

### Example 2: Tiered Loading
```javascript
// Task: Implement user login
// Tier 1 always loaded: ROADMAP.md, STATE.md

// Task needs examples? Load Tier 2
if (taskDescription.includes('example')) {
  loadFile('few-shot-examples/auth.md');
}

// NEVER auto-load Tier 3
// workflows/auth.md is 50KB - load only if user asks
```

### Example 3: ROI Tracking
```bash
# After completing phase 1
echo "1,auth,$(date +%s),52000" >> .planning/TOKEN_USAGE.csv

# Calculate savings
TRADITIONAL=150000
GOGETA=52000
SAVED=$((TRADITIONAL - GOGETA))
ROI=$((SAVED * 100 / TRADITIONAL))
echo "💰 Saved $SAVED tokens ($ROI% reduction) vs traditional approach"
```

## ✅ Checklist

### Token Budget System Active When:
- [ ] Token tracking enabled (get_current_token_count works)
- [ ] Budget threshold set (40% of context limit)
- [ ] Checkpoint saving on >40% usage
- [ ] Tiered docs loading implemented
- [ ] Relevance-based pruning active
- [ ] Cost/ROI tracking to .planning/TOKEN_USAGE.csv
- [ ] A/B telemetry logging (if enabled)

### Commands Enhanced:
- `/gogeta-execute-phase` - Now budget-aware
- `/gogeta-resume-work` - Reads checkpoints
- `/gogeta-debug` - Tiered doc loading
- `/gogeta-plan-phase` - ROI tracking enabled
