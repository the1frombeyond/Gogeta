# Instructions for GOGETA

- Use the gogeta-cli skill when the user asks for GOGETA or uses a `gogeta-*` command.
- Treat `/gogeta-...` or `gogeta-...` as command invocations and load the matching file from `.github/skills/gogeta-*`.
- When a command says to spawn a subagent, prefer a matching custom agent from `.github/agents`.
- Do not apply GOGETA workflows unless the user explicitly asks for them.
- After completing any `gogeta-*` command (or any deliverable it triggers: feature, bug fix, tests, docs, etc.), ALWAYS: (1) offer the user the next step by prompting via `ask_user`; repeat this feedback loop until the user explicitly indicates they are done.
