---
description: AI code completion and next-step prediction
---

# Code Predict

AI-powered code completion and intelligent next-step prediction.

## ?? USAGE
```
/gogeta-code-predict [context] [options]
```

## ? FEATURES

### 1. Smart Code Completion
Context-aware code suggestions as you type.
- Understands your coding style
- Predicts entire functions
- Suggests idiomatic patterns
- Completes complex expressions

### 2. Next-Step Prediction
Predicts what you want to do next.
- Analyzes current code context
- Suggests logical next steps
- Predicts bugs before they happen
- Recommends refactoring opportunities

### 3. Intent Prediction
Understands what you're trying to build.
- Analyzes comments and intent
- Predicts implementation approach
- Suggests relevant libraries
- Recommends architecture patterns

### 4. Bug Prediction
Predicts bugs before you write them.
- Detects likely error patterns
- Warns about edge cases
- Predicts performance issues
- Suggests defensive coding

## Prediction Types

### Code Completion
```javascript
// You type:
function calculateTotal(items) {
  return items.
// AI predicts:
  reduce((sum, item) => sum + item.price, 0);
```

### Next-Step Suggestions
```
Current context: Just created User model
AI suggests:
1. Create UserController
2. Add validation middleware
3. Write User tests
4. Create User API endpoints
```

### Intent Prediction
```
You: "I need to add authentication"
AI predicts you'll need:
1. User login endpoint
2. JWT token generation
3. Password hashing
4. Session management
5. Auth middleware
```

### Bug Prevention
```
You're writing:
for (let i = 0; i < array.length; i++) {
  // AI warns: "Potential off-by-one error. Did you mean <= ?"
}
```

## Context Awareness

### Code Context
- Current file and function
- Imported modules
- Variable types and shapes
- Recent edits and patterns

### Project Context
- Project structure
- Framework and libraries
- Coding conventions
- Existing patterns

### User Context
- Your coding style
- Common mistakes
- Preferred patterns
- Skill level

## Integration

### IDE Integration
- VS Code extension
- JetBrains plugin
- Vim/Neovim support
- Emacs support

### Real-Time Suggestions
- Inline completions
- Hover suggestions
- Quick fixes
- Refactoring hints

## ?? EXAMPLES

Get code completion:
```
/gogeta-code-predict complete "function sortArray(arr) {"
```

Predict next steps:
```
/gogeta-code-predict next-steps
```

Predict intent:
```
/gogeta-code-predict intent "building a REST API"
```

Prevent bugs:
```
/gogeta-code-predict check-bugs src/utils.js
```

## ?? OUTPUT
- Code completions (multiple options)
- Next-step suggestions (ranked)
- Intent predictions (with confidence)
- Bug warnings (with fixes)
- Refactoring suggestions
- Learning resources

## ?? NOTES
- Learns from your coding patterns
- Gets smarter over time
- Respects your coding style
- Can be trained on your codebase
- Works offline after initial setup!

