---
name: GOGETA:progress
description: Check project progress, show context, and route to next action (execute or plan). Use --forensic to append a 6-check integrity audit after the standard report.
argument-hint: "[--forensic]"
allowed-tools:
  - Read
  - Bash
  - Grep
  - Glob
  - SlashCommand
---
## ?? OBJECTIVE
Check project progress, summarize recent work and what's ahead, then intelligently route to the next action - either executing ### ?? Trigger plan or creating the next one.

Provides situational awareness before continuing work.


## ?? EXECUTION CONTEXT
@~/.claude/gogeta-cli/workflows/progress.md


## ? PROCESS
Execute the progress workflow from @~/.claude/gogeta-cli/workflows/progress.md end-to-end.
Preserve all routing logic (Routes A through F) and edge case handling.



