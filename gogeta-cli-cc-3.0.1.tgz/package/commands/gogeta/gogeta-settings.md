---
name: GOGETA:settings
description: Configure GOGETA workflow toggles and model profile
allowed-tools:
  - Read
  - Write
  - Bash
  - AskUserQuestion
---

## ?? OBJECTIVE
Interactive configuration of GOGETA workflow agents and model profile via multi-question prompt.

### ?? Trigger
- Config existence ensuring
- Current settings reading and parsing
- Interactive 5-question prompt (model, research, plan_check, verifier, branching)
- Config merging and writing
- Confirmation display with quick command references


## ?? EXECUTION CONTEXT
@~/.claude/gogeta-cli/workflows/settings.md


## ? PROCESS
**Follow the settings workflow** from `@~/.claude/gogeta-cli/workflows/settings.md`.

The workflow handles all logic including:
1. Config file creation with defaults if missing
2. Current config reading
3. Interactive settings presentation with pre-selection
4. Answer parsing and config merging
5. File writing
6. Confirmation display



