---
name: GOGETA:join-discord
description: Join the GOGETA Discord community
allowed-tools: []
---

## ?? OBJECTIVE
Display the Discord invite link for the GOGETA community server.


<output>
# Join the GOGETA Discord

Connect with other GOGETA users, get help, share what you're building, and stay updated.

**Invite link:** https://discord.gg/mYgfVNfA2r

Click the link or paste it into your browser to join.
</output>

