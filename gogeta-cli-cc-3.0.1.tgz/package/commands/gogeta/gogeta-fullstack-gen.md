---
description: Generate full-stack applications from description
---

# Full-Stack Generator

Generate complete full-stack applications from natural language descriptions.

## ?? USAGE
```
/gogeta-fullstack-gen [description] [options]
```

## ?? PARAMETERS
- `description` - Description of the application to build
- `options` - Generation options (frontend, backend, database, all)

## What It Generates

### 1. Frontend
- React/Vue/Angular project setup
- Component structure
- Routing configuration
- State management
- API integration layer
- UI components with styling
- Forms with validation
- Authentication UI
- Responsive layouts

### 2. Backend
- Express/Fastify/Koa setup
- API route structure
- Middleware configuration
- Authentication/authorization
- Database models/ORM
- Business logic layers
- Error handling
- Logging setup
- API documentation (OpenAPI)

### 3. Database
- Schema design
- Migration files
- Seed data
- Index optimization
- Relationship mapping

### 4. DevOps
- Docker configuration
- Docker-compose setup
- CI/CD pipelines
- Environment configs
- Deployment scripts

## Example Descriptions

### E-Commerce App
```
/gogeta-fullstack-gen "E-commerce platform with product catalog, shopping cart, 
user authentication, order management, payment integration with Stripe, 
admin dashboard, and inventory management"
```

Output:
```
✓ Created frontend/ (React + Next.js)
  - ProductCatalog, ShoppingCart, Checkout components
  - User authentication flow
  - Admin dashboard pages
  
✓ Created backend/ (Node.js + Express)
  - /api/products, /api/orders, /api/users routes
  - Stripe payment integration
  - JWT authentication
  
✓ Created database/ (PostgreSQL)
  - products, users, orders, inventory tables
  - Migrations and seeds
  
✓ Created docker-compose.yml
✓ Created CI/CD pipeline (GitHub Actions)
✓ Generated README with setup instructions
```

### Task Management App
```
/gogeta-fullstack-gen "Real-time task management app with drag-and-drop, 
team collaboration, notifications, and calendar view" --stack MERN
```

## Stacks Supported

### Frontend Options
- React (Next.js, CRA, Vite)
- Vue (Nuxt, Quasar)
- Angular
- Svelte (SvelteKit)

### Backend Options
- Node.js (Express, Fastify, NestJS)
- Python (Django, Flask, FastAPI)
- Go (Gin, Echo)
- Java (Spring Boot)
- Ruby (Rails)

### Database Options
- PostgreSQL
- MySQL
- MongoDB
- SQLite
- Redis (caching)

## ? PROCESS

1. **Requirement Parsing**
   - Extract features from description
   - Identify entities and relationships
   - Determine technical requirements

2. **Architecture Design**
   - Choose optimal tech stack
   - Design database schema
   - Plan API structure
   - Design component hierarchy

3. **Code Generation**
   - Generate all project files
   - Implement features
   - Add proper error handling
   - Include tests
   - Add documentation

4. **Integration**
   - Wire frontend to backend
   - Configure CORS, proxies
   - Set up environment variables
   - Connect database

5. **Verification**
   - Run generated tests
   - Check for TypeScript errors
   - Validate build process
   - Test critical paths

## ? FEATURES

### Smart Defaults
- Follows best practices
- Industry-standard patterns
- Security by default
- Production-ready code

### Customizable
- Choose your tech stack
- Modify generated code
- Add custom features
- Extend as needed

### Integrated
- Frontend and backend work together
- Consistent error handling
- Shared types/interfaces
- Unified logging

## Options

```
--frontend <framework>    Choose frontend (react, vue, angular)
--backend <framework>     Choose backend (express, django, flask)
--database <type>         Choose database (postgres, mysql, mongo)
--auth <type>             Authentication type (jwt, session, oauth)
--css <framework>         CSS framework (tailwind, bootstrap, none)
--orm <type>              ORM choice (prisma, sequelize, mongoose)
--skip-tests              Skip test generation
--skip-docs               Skip documentation
--minimal                 Generate minimal boilerplate only
```

## ?? OUTPUT Structure

```
my-app/
├── frontend/
│   ├── src/
│   │   ├── components/
│   │   ├── pages/
│   │   ├── hooks/
│   │   ├── services/
│   │   └── utils/
│   ├── public/
│   ├── package.json
│   └── README.md
├── backend/
│   ├── src/
│   │   ├── routes/
│   │   ├── models/
│   │   ├── middleware/
│   │   ├── services/
│   │   └── utils/
│   ├── package.json
│   └── README.md
├── database/
│   ├── migrations/
│   ├── seeds/
│   └── schema.sql
├── docker-compose.yml
├── .env.example
└── README.md
```

## ?? EXAMPLES

Generate a blog platform:
```
/gogeta-fullstack-gen "Blog platform with markdown editor, comments, 
user roles, tags, search, and RSS feed"
```

Generate with specific stack:
```
/gogeta-fullstack-gen "Chat application" --frontend react --backend node --database mongo
```

Minimal generation:
```
/gogeta-fullstack-gen "Todo app" --minimal --skip-tests
```

## ?? NOTES
- Generates production-ready code
- Includes comprehensive error handling
- Sets up proper project structure
- Creates deployable applications
- Saves hours of boilerplate coding!

