---
name: GOGETA:sketch
description: Sketch UI/design ideas with throwaway HTML mockups, or propose what to sketch next (frontier mode)
argument-hint: "[design idea to explore] [--quick] [--text] or [frontier]"
allowed-tools:
  - Read
  - Write
  - Edit
  - Bash
  - Grep
  - Glob
  - AskUserQuestion
  - WebSearch
  - WebFetch
  - mcp__context7__resolve-library-id
  - mcp__context7__query-docs
---
## ?? OBJECTIVE
Explore design directions through throwaway HTML mockups before committing to implementation.
Each sketch produces 2-3 variants for comparison. Sketches live in `.planning/sketches/` and
integrate with GOGETA commit patterns, state tracking, and handoff workflows. Loads spike
findings to ground mockups in real data shapes and validated interaction patterns.

Two modes:
- **Idea mode** (default) — describe a design idea to sketch
- **Frontier mode** (no argument or "frontier") — analyzes existing sketch landscape and proposes consistency and frontier sketches

Does not require `/gogeta-new-project` — auto-creates `.planning/sketches/` if needed.


## ?? EXECUTION CONTEXT
@~/.claude/gogeta-cli/workflows/sketch.md
@~/.claude/gogeta-cli/references/ui-brand.md
@~/.claude/gogeta-cli/references/sketch-theme-system.md
@~/.claude/gogeta-cli/references/sketch-interactivity.md
@~/.claude/gogeta-cli/references/sketch-tooling.md
@~/.claude/gogeta-cli/references/sketch-variant-patterns.md


<runtime_note>
**Copilot (VS Code):** Use `vscode_askquestions` wherever this workflow calls `AskUserQuestion`.
</runtime_note>

## ?? CONTEXT
Design idea: $ARGUMENTS

**Available flags:**
- `--quick` — Skip mood/direction intake, jump straight to decomposition and building. Use when the design direction is already clear.


## ? PROCESS
Execute the sketch workflow from @~/.claude/gogeta-cli/workflows/sketch.md end-to-end.
Preserve all workflow gates (intake, decomposition, target stack research, variant evaluation, MANIFEST updates, commit patterns).



