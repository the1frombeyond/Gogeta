---
name: GOGETA:list-workspaces
description: List active GOGETA workspaces and their status
allowed-tools:
  - Bash
  - Read
---
## ?? OBJECTIVE
Scan `~/gogeta-workspaces/` for workspace directories containing `WORKSPACE.md` manifests. Display a summary table with name, path, repo count, strategy, and GOGETA project status.


## ?? EXECUTION CONTEXT
@~/.claude/gogeta-cli/workflows/list-workspaces.md
@~/.claude/gogeta-cli/references/ui-brand.md


## ? PROCESS
Execute the list-workspaces workflow from @~/.claude/gogeta-cli/workflows/list-workspaces.md end-to-end.



