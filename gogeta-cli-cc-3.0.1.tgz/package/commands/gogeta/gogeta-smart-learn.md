---
description: AI that learns your codebase and coding patterns
---

# Smart Learn

AI that continuously learns your codebase, coding patterns, and team conventions.

## ?? USAGE
```
/gogeta-smart-learn [action] [options]
```

## ?? ACTIONS

### 1. Learn Codebase
Deep analysis and learning of your codebase.
```
/gogeta-smart-learn codebase
```
Learns:
- Code organization patterns
- Naming conventions
- Architecture decisions
- Common abstractions
- Error handling patterns
- Testing approaches
- Documentation style

### 2. Learn Patterns
Identify and learn coding patterns.
```
/gogeta-smart-learn patterns
```
Detects:
- Design patterns used
- Anti-patterns to avoid
- Team coding preferences
- Framework usage patterns
- API design style
- Database query patterns

### 3. Learn Team
Learn team collaboration patterns.
```
/gogeta-smart-learn team
```
Analyzes:
- Git commit message style
- PR review patterns
- Branching strategies
- Code review preferences
- Documentation habits
- Communication style

### 4. Suggest Improvements
Get AI suggestions based on learned patterns.
```
/gogeta-smart-learn suggest
```
Provides:
- Code improvements based on your patterns
- Architecture suggestions
- Refactoring opportunities
- Consistency improvements
- Best practice alignments

### 5. Export Knowledge
Export learned knowledge for sharing.
```
/gogeta-smart-learn export [file]
```
Exports:
- Codebase knowledge base
- Pattern library
- Team conventions
- Best practices
- Common pitfalls

## Learning Features

### Continuous Learning
- Watches file changes
- Updates knowledge in real-time
- Learns from your edits
- Adapts to evolving patterns

### Context Awareness
- Understands project structure
- Knows your tech stack
- Recognizes dependencies
- Tracks architectural decisions

### Smart Suggestions
- Suggests based on learned patterns
- Predicts your coding intent
- Warns about deviations
- Recommends consistent approaches

### Team Learning
- Learns from entire team's commits
- Aggregates coding styles
- Finds team consensus
- Suggests team standards

## Knowledge Base

The AI builds a knowledge base stored in `.gogeta/knowledge/`:
```
.gogeta/knowledge/
├── codebase-map.json      # Code structure
├── patterns.json          # Detected patterns
├── conventions.json       # Team conventions
├── anti-patterns.json     # Things to avoid
└── suggestions.json       # Improvement ideas
```

## ?? EXAMPLES

Learn the entire codebase:
```
/gogeta-smart-learn codebase --deep
```

Get suggestions based on learned patterns:
```
/gogeta-smart-learn suggest src/new-feature/
```

Export knowledge for new team member:
```
/gogeta-smart-learn export team-knowledge.json
```

Show what AI has learned:
```
/gogeta-smart-learn status
```

## Integration

### IDE Integration
- Shows suggestions as you type
- Highlights deviations from patterns
- Recommends consistent approaches

### Code Review
- Checks PRs against learned patterns
- Suggests improvements
- Ensures consistency

### Onboarding
- New team members get instant knowledge
- Understand project conventions faster
- Reduce onboarding time by 70%

## ?? OUTPUT
- Knowledge base files (JSON)
- Pattern visualization
- Suggestion reports
- Learning progress dashboard
- Team convention documents

## ?? NOTES
- Learns continuously in background
- Respects .gitignore
- Privacy-focused (local only)
- Improves over time
- Makes your code more consistent!

