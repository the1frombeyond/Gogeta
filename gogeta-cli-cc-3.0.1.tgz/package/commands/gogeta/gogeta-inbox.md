---
name: GOGETA:inbox
description: Triage and review all open GitHub issues and PRs against project templates and contribution guidelines
argument-hint: "[--issues] [--prs] [--label] [--close-incomplete] [--repo owner/repo]"
allowed-tools:
  - Read
  - Bash
  - Write
  - Grep
  - Glob
  - AskUserQuestion
---
## ?? OBJECTIVE
One-command triage of the project's GitHub inbox. Fetches all open issues and PRs,
reviews each against the corresponding template requirements (feature, enhancement,
bug, chore, fix PR, enhancement PR, feature PR), reports completeness and compliance,
and optionally applies labels or closes non-compliant submissions.

**Flow:** Detect repo → Fetch open issues + PRs → Classify each by type → Review against template → Report findings → Optionally act (label, comment, close)


## ?? EXECUTION CONTEXT
@~/.claude/gogeta-cli/workflows/inbox.md


## ?? CONTEXT
**Flags:**
- `--issues` — Review only issues (skip PRs)
- `--prs` — Review only PRs (skip issues)
- `--label` — Auto-apply recommended labels after review
- `--close-incomplete` — Close issues/PRs that fail template compliance (with comment explaining why)
- `--repo owner/repo` — Override auto-detected repository (defaults to current git remote)


## ? PROCESS
Execute the inbox workflow from @~/.claude/gogeta-cli/workflows/inbox.md end-to-end.
Parse flags from arguments and pass to workflow.



