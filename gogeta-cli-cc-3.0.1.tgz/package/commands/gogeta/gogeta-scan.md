---
name: GOGETA:scan
description: Rapid codebase assessment — lightweight alternative to /gogeta-map-codebase
allowed-tools:
  - Read
  - Write
  - Bash
  - Grep
  - Glob
  - Agent
  - AskUserQuestion
---
## ?? OBJECTIVE
Run a focused codebase scan for a single area, producing targeted documents in `.planning/codebase/`.
Accepts an optional `--focus` flag: `tech`, `arch`, `quality`, `concerns`, or `tech+arch` (default).

Lightweight alternative to `/gogeta-map-codebase` — spawns one mapper agent instead of four parallel ones.


## ?? EXECUTION CONTEXT
@~/.claude/gogeta-cli/workflows/scan.md


## ? PROCESS
Execute the scan workflow from @~/.claude/gogeta-cli/workflows/scan.md end-to-end.



