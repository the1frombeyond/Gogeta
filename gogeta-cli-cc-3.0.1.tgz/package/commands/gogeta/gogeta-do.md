---
name: GOGETA:do
description: Route freeform text to the right GOGETA command automatically
argument-hint: "<description of what you want to do>"
allowed-tools:
  - Read
  - Bash
  - AskUserQuestion
---
## ?? OBJECTIVE
Analyze freeform natural language input and dispatch to the most appropriate GOGETA command.

Acts as a smart dispatcher — never does the work itself. Matches intent to the best GOGETA command using routing rules, confirms the match, then hands off.

Use when you know what you want but don't know which `/gogeta-*` command to run.


## ?? EXECUTION CONTEXT
@~/.claude/gogeta-cli/workflows/do.md
@~/.claude/gogeta-cli/references/ui-brand.md


## ?? CONTEXT
$ARGUMENTS


## ? PROCESS
Execute the do workflow from @~/.claude/gogeta-cli/workflows/do.md end-to-end.
Route user intent to the best GOGETA command and invoke it.



