---
description: Voice-controlled coding with speech recognition
---

# Voice Commands

Control GOGETA CLI using voice commands with speech recognition.

## ?? USAGE
```
/gogeta-voice [action]
```

## ?? ACTIONS

### 1. Start Listening
Activate voice command mode.
```
/gogeta-voice start
```
- Listens for voice commands
- Shows visual feedback
- Processes speech in real-time

### 2. Available Voice Commands
- "generate [description]" - Generate code from voice description
- "debug [error]" - Debug using voice-described error
- "refactor [target]" - Trigger refactoring via voice
- "test [target]" - Run tests via voice
- "commit" - Generate and commit changes
- "help" - List available voice commands
- "stop" - Exit voice mode

### 3. Voice Coding Examples
- "gogeta generate a login form with validation"
- "gogeta debug cannot read property of undefined"
- "gogeta refactor the utils folder"

## ? FEATURES

- **Natural Language Processing**: Understands coding intent from speech
- **Multi-language Support**: Recognizes technical terms in multiple languages
- **Background Mode**: Continuous listening while coding
- **Keyboard Toggle**: Quick voice mode toggle with hotkey
- **Noise Cancellation**: Filters background noise for accuracy

## Requirements

- Microphone access
- Speech recognition API (browser-based or local)
- Optional: GPU acceleration for faster processing

## ?? EXAMPLES

Start voice mode:
```
/gogeta-voice start
```

Then speak: "generate a REST API for user management"

## ?? NOTES
- Works best in quiet environments
- Technical terms may need clear pronunciation
- Can be combined with text commands
- Voice history saved for review

