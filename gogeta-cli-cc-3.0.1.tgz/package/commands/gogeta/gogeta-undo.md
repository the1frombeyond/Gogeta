---
name: GOGETA:undo
description: "Safe git revert. Roll back phase or plan commits using the phase manifest with dependency checks."
argument-hint: "--last N | --phase NN | --plan NN-MM"
allowed-tools:
  - Read
  - Bash
  - Glob
  - Grep
  - AskUserQuestion
---

## ?? OBJECTIVE
Safe git revert — roll back GOGETA phase or plan commits using the phase manifest, with dependency checks and a confirmation gate before execution.

Three modes:
- **--last N**: Show recent GOGETA commits for interactive selection
- **--phase NN**: Revert all commits for a phase (manifest + git log fallback)
- **--plan NN-MM**: Revert all commits for a specific plan


## ?? EXECUTION CONTEXT
@~/.claude/gogeta-cli/workflows/undo.md
@~/.claude/gogeta-cli/references/ui-brand.md
@~/.claude/gogeta-cli/references/gate-prompts.md


## ?? CONTEXT
$ARGUMENTS


## ? PROCESS
Execute the undo workflow from @~/.claude/gogeta-cli/workflows/undo.md end-to-end.



