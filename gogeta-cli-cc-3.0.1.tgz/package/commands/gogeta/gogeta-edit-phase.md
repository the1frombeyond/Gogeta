---
name: GOGETA:edit-phase
description: Edit any field of ### ?? Trigger roadmap phase in place, preserving number and position
argument-hint: <phase-number> [--force]
allowed-tools:
  - Read
  - Write
  - Bash
---

## ?? OBJECTIVE
Modify any field of ### ?? Trigger phase in ROADMAP.md in place.

Supports:
- Editing individual fields (title, description/goal, requirements, success criteria, depends_on)
- Full regeneration of all fields from a clarified intent
- Guarded edits: refuses in_progress/completed phases unless --force is passed
- Depends-on validation: blocks invalid references with a clear error
- Diff + confirmation before writing


## ?? EXECUTION CONTEXT
@~/.claude/gogeta-cli/workflows/edit-phase.md


## ?? CONTEXT
Arguments: $ARGUMENTS (format: <phase-number> [--force])

Roadmap and state are resolved in-workflow via `init phase-op` and targeted reads.


## ? PROCESS
Execute the edit-phase workflow from @~/.claude/gogeta-cli/workflows/edit-phase.md end-to-end.
Preserve all validation gates (phase existence, status guard, depends_on validation, diff + confirmation).



