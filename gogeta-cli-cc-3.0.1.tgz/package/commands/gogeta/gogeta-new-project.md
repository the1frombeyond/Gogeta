---
name: GOGETA:new-project
description: Initialize a new project with deep context gathering and PROJECT.md
argument-hint: "[--auto]"
allowed-tools:
  - Read
  - Bash
  - Write
  - Task
  - AskUserQuestion
---
<runtime_note>
**Copilot (VS Code):** Use `vscode_askquestions` wherever this workflow calls `AskUserQuestion`. They are equivalent — `vscode_askquestions` is the VS Code Copilot implementation of the same interactive question API.
</runtime_note>

## ?? CONTEXT
**Flags:**
- `--auto` — Automatic mode. After config questions, runs research → requirements → roadmap without further interaction. Expects idea document via @ reference.


## ?? OBJECTIVE
Initialize a new project through unified flow: questioning → research (optional) → requirements → roadmap.

**Creates:**
- `.planning/PROJECT.md` — project context
- `.planning/config.json` — workflow preferences
- `.planning/research/` — domain research (optional)
- `.planning/REQUIREMENTS.md` — scoped requirements
- `.planning/ROADMAP.md` — phase structure
- `.planning/STATE.md` — project memory

**After this command:** Run `/gogeta-plan-phase 1` to start execution.


## ?? EXECUTION CONTEXT
@~/.claude/gogeta-cli/workflows/new-project.md
@~/.claude/gogeta-cli/references/questioning.md
@~/.claude/gogeta-cli/references/ui-brand.md
@~/.claude/gogeta-cli/templates/project.md
@~/.claude/gogeta-cli/templates/requirements.md


## ? PROCESS
Execute the new-project workflow from @~/.claude/gogeta-cli/workflows/new-project.md end-to-end.
Preserve all workflow gates (validation, approvals, commits, routing).



