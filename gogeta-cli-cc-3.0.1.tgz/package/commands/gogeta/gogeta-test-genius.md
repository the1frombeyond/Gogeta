---
description: AI-powered test generation with edge case discovery
---

# Test Genius

Intelligent test generation that discovers edge cases and creates comprehensive test suites.

## Usage
```
/gogeta-test-genius [target] [options]
```

## Parameters
- `target` - Function, file, or module to test
- `options` - Test options (unit, integration, e2e, all)

## Test Generation Types

### 1. Unit Tests
- Generate tests for individual functions
- Mock dependencies intelligently
- Achieve high code coverage
- Test all code paths

### 2. Integration Tests
- Test component interactions
- API endpoint testing
- Database integration tests
- Service communication tests

### 3. E2E Tests
- User journey testing
- Critical path validation
- Cross-browser testing (if UI)
- Performance benchmarks

### 4. Edge Case Discovery
- AI analyzes code to find edge cases
- Boundary value analysis
- Null/undefined handling
- Type coercion issues
- Async race conditions
- Error scenarios

## Process

1. **Code Analysis**
   - Parse function signatures and types
   - Understand logic flow
   - Identify inputs and outputs
   - Detect side effects

2. **Test Strategy**
   - Determine test types needed
   - Identify critical paths
   - Plan coverage targets
   - Consider testing frameworks

3. **Test Generation**
   - Write meaningful test cases
   - Include setup/teardown
   - Add proper assertions
   - Mock external dependencies
   - Generate test data

4. **Edge Case Injection**
   - Deliberately test boundaries
   - Inject fault scenarios
   - Test error handling
   - Verify graceful degradation

5. **Validation**
   - Run generated tests
   - Check coverage metrics
   - Verify assertions pass
   - Identify gaps

## Features

### Smart Mocking
- Automatically mocks dependencies
- Generates realistic mock data
- Handles complex object shapes
- Supports async mocking

### Coverage Optimization
- Focuses on untested paths
- Avoids redundant tests
- Prioritizes critical code
- Achieves 80%+ coverage goal

### Framework Detection
- Detects Jest, Mocha, Vitest, Jasmine
- Uses project's testing framework
- Follows existing patterns
- Respects configuration

### Snapshot Testing
- Generates snapshot tests
- UI component testing
- API response snapshots
- Config file snapshots

## Examples

Generate unit tests for a function:
```
/gogeta-test-genius src/utils/validator.js
```

Generate all test types:
```
/gogeta-test-genius src/api/auth.js --all
```

Generate with edge cases:
```
/gogeta-test-genius . --edge-cases-only
```

## Output

- Test files in `__tests__` or `__test__` directory
- Mocks in `__mocks__` directory
- Test data factories
- Coverage report
- Test execution results

## Notes
- Learns from existing test patterns
- Follows project coding style
- Includes meaningful test descriptions
- Generates maintainable tests
- Supports TDD/BDD styles
