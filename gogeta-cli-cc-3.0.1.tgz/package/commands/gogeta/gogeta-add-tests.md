---
name: GOGETA:add-tests
description: Generate tests for a completed phase based on UAT criteria and implementation
argument-hint: "<phase> [additional instructions]"
allowed-tools:
  - Read
  - Write
  - Edit
  - Bash
  - Glob
  - Grep
  - Task
  - AskUserQuestion
argument-instructions: |
  Parse the argument as a phase number (integer, decimal, or letter-suffix), plus optional free-text instructions.
  Example: /gogeta-add-tests 12
  Example: /gogeta-add-tests 12 focus on edge cases in the pricing module
---
## ?? OBJECTIVE
Generate unit and E2E tests for a completed phase, using its SUMMARY.md, CONTEXT.md, and VERIFICATION.md as specifications.

Analyzes implementation files, classifies them into TDD (unit), E2E (browser), or Skip categories, presents a test plan for user approval, then generates tests following RED-GREEN conventions.

Output: Test files committed with message `test(phase-{N}): add unit and E2E tests from add-tests command`


## ?? EXECUTION CONTEXT
@~/.claude/gogeta-cli/workflows/add-tests.md


## ?? CONTEXT
Phase: $ARGUMENTS

@.planning/STATE.md
@.planning/ROADMAP.md


## ? PROCESS
Execute the add-tests workflow from @~/.claude/gogeta-cli/workflows/add-tests.md end-to-end.
Preserve all workflow gates (classification approval, test plan approval, RED-GREEN verification, gap reporting).



