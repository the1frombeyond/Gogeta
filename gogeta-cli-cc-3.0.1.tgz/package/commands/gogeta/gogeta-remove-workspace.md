---
name: GOGETA:remove-workspace
description: Remove a GOGETA workspace and clean up worktrees
argument-hint: "<workspace-name>"
allowed-tools:
  - Bash
  - Read
  - AskUserQuestion
---
## ?? CONTEXT
**Arguments:**
- `<workspace-name>` (required) — Name of the workspace to remove


## ?? OBJECTIVE
Remove a workspace directory after confirmation. For worktree strategy, runs `git worktree remove` for each member repo first. Refuses if any repo has uncommitted changes.


## ?? EXECUTION CONTEXT
@~/.claude/gogeta-cli/workflows/remove-workspace.md
@~/.claude/gogeta-cli/references/ui-brand.md


## ? PROCESS
Execute the remove-workspace workflow from @~/.claude/gogeta-cli/workflows/remove-workspace.md end-to-end.



