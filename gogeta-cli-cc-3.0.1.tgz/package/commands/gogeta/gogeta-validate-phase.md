---
name: GOGETA:validate-phase
description: Retroactively audit and fill Nyquist validation gaps for a completed phase
argument-hint: "[phase number]"
allowed-tools:
  - Read
  - Write
  - Edit
  - Bash
  - Glob
  - Grep
  - Task
  - AskUserQuestion
---
## ?? OBJECTIVE
Audit Nyquist validation coverage for a completed phase. Three states:
- (A) VALIDATION.md exists — audit and fill gaps
- (B) No VALIDATION.md, SUMMARY.md exists — reconstruct from artifacts
- (C) Phase not executed — exit with guidance

Output: updated VALIDATION.md + generated test files.


## ?? EXECUTION CONTEXT
@~/.claude/gogeta-cli/workflows/validate-phase.md


## ?? CONTEXT
Phase: $ARGUMENTS — optional, defaults to last completed phase.


## ? PROCESS
Execute @~/.claude/gogeta-cli/workflows/validate-phase.md.
Preserve all workflow gates.



