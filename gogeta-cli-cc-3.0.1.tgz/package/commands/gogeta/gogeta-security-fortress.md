---
description: Advanced security scanning and vulnerability fixing
---

# Security Fortress

Military-grade security scanning with automatic vulnerability remediation.

## Usage
```
/gogeta-security-fortress [target] [options]
```

## Parameters
- `target` - File, directory, or project to scan
- `options` - Scan options (owasp, cve, all)

## Security Scans

### 1. OWASP Top 10 Scan
- Injection flaws (SQL, NoSQL, LDAP)
- Broken authentication
- Sensitive data exposure
- XML external entities (XXE)
- Broken access control
- Security misconfiguration
- Cross-site scripting (XSS)
- Insecure deserialization
- Using components with known vulnerabilities
- Insufficient logging and monitoring

### 2. CVE Vulnerability Scan
- National Vulnerability Database (NVD) lookup
- Package vulnerability detection
- Known exploit checking
- Severity scoring (CVSS)
- Affected version detection

### 3. Secret Detection
- API keys and tokens
- Private keys and certificates
- Passwords in code/config
- Hardcoded credentials
- .env file leaks

### 4. Dependency Scan
- npm/yarn/pip/maven vulnerabilities
- Transitive dependency risks
- License compliance
- Outdated package detection
- Malware detection in packages

### 5. Code Security Analysis
- Input validation flaws
- Output encoding issues
- Race condition detection
- Insecure cryptography usage
- Privilege escalation risks
- File system access violations

## Auto-Fix Features

### Automatic Patching
- Patches vulnerable dependencies
- Fixes common security anti-patterns
- Adds missing security headers
- Implements input sanitization
- Adds rate limiting templates

### Security Hardening
- Generates security configuration
- Creates security middleware
- Adds authentication templates
- Implements authorization checks
- Sets up audit logging

## Process

1. **Deep Scan**
   - Static Application Security Testing (SAST)
   - Dynamic Analysis (DAST) preparation
   - Dependency Check
   - Secret Scanning
   - Configuration Review

2. **Risk Assessment**
   - CVSS scoring
   - Exploitability analysis
   - Business impact assessment
   - Likelihood calculation

3. **Remediation**
   - Generate fix code
   - Create pull requests
   - Update dependencies
   - Apply security patches
   - Configure security tools

4. **Verification**
   - Re-scan after fixes
   - Penetration test simulation
   - Compliance verification
   - Security regression test

## Output

### Security Report
```
Security Scan Report: src/
========================

Critical Issues (2):
1. [CVE-2024-1234] express@4.17.1 - Remote Code Execution
   Fix: npm install express@4.18.2
   
2. [Secret] API key found in config.js:12
   Fix: Move to environment variable

High Issues (5):
1. [OWASP A3] SQL injection in user.js:89
   Fix: Use parameterized queries
   
2. [OWASP A7] XSS vulnerability in renderProfile()
   Fix: Add output encoding
...

Recommendations:
- Enable Helmet.js security headers
- Implement rate limiting
- Add CSRF protection
- Set up security monitoring
```

### Compliance Reports
- OWASP compliance status
- PCI-DSS checklist (if applicable)
- GDPR compliance (if applicable)
- SOC2 controls mapping

## Examples

Full security scan:
```
/gogeta-security-fortress . --all
```

Scan and auto-fix:
```
/gogeta-security-fortress . --fix --auto-commit
```

OWASP-focused scan:
```
/gogeta-security-fortress src/ --owasp
```

Check for secrets only:
```
/gogeta-security-fortress . --secrets-only
```

## Integration

- **Pre-commit Hooks**: Block commits with vulnerabilities
- **CI/CD**: Fail builds on critical issues
- **Monitoring**: Continuous security monitoring
- **Alerts**: Slack/email notifications

## Notes
- Uses multiple vulnerability databases
- Learns from security advisories
- Respects .gitignore and security exclusions
- Can scan Docker images and containers
- Supports 30+ programming languages
