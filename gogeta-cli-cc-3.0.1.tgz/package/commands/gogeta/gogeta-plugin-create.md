---
description: Create and manage GOGETA CLI plugins
---

# Plugin System

Extensible plugin architecture for custom GOGETA CLI commands.

## ?? USAGE
```
/gogeta-plugin [action] [options]
```

## ?? ACTIONS

### 1. Create Plugin
Scaffold a new plugin structure.
```
/gogeta-plugin create <plugin-name>
```
Creates:
- `plugins/<plugin-name>/`
  - `plugin.json` - Plugin manifest
  - `commands/` - Custom commands
  - `agents/` - Custom agents
  - `hooks/` - Custom hooks
  - `README.md` - Plugin documentation

### 2. Install Plugin
Install a plugin from local or remote source.
```
/gogeta-plugin install <source>
```
Sources:
- Local path: `./my-plugin`
- NPM package: `gogeta-plugin-<name>`
- Git repo: `github:user/repo`

### 3. List Plugins
Show installed plugins.
```
/gogeta-plugin list
```

### 4. Remove Plugin
Uninstall a plugin.
```
/gogeta-plugin remove <plugin-name>
```

### 5. Update Plugins
Update all plugins to latest versions.
```
/gogeta-plugin update
```

## Plugin Structure

**plugin.json**:
```json
{
  "name": "gogeta-plugin-example",
  "version": "1.0.0",
  "description": "Example plugin",
  "author": "Your Name",
  "commands": ["./commands"],
  "agents": ["./agents"],
  "hooks": ["./hooks"],
  "dependencies": {}
}
```

## Creating Custom Commands

Create `commands/my-command.md`:
```markdown
---
description: My custom command
---

# My Command

/gogeta-my-command [args]

## ? PROCESS
1. Step 1
2. Step 2
```

## Plugin Examples

### 1. Language Support Plugin
Add support for a new programming language with specialized commands.

### 2. Framework Plugin
Add React, Vue, or Angular-specific workflows.

### 3. Integration Plugin
Connect to JIRA, Slack, or other tools.

### 4. Theme Plugin
Customize GOGETA CLI appearance and output format.

## Plugin API

Plugins can access:
- GOGETA CLI core functions
- Project state and config
- File system operations
- AI model access
- Event hooks

## ?? EXAMPLES

Create a new plugin:
```
/gogeta-plugin create my-awesome-plugin
```

Install a plugin:
```
/gogeta-plugin install ./my-plugin
```

List installed plugins:
```
/gogeta-plugin list
```

## ?? NOTES
- Plugins run in sandbox mode by default
- Requires restart after install/remove
- Check plugin compatibility before installing
- Contribute plugins to the GOGETA ecosystem!

