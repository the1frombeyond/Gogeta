---
description: Deep AI code review with actionable insights
---

# AI Code Review

Comprehensive AI-powered code review with deep analysis and actionable insights.

## ?? USAGE
```
/gogeta-ai-code-review [target] [options]
```

## ?? PARAMETERS
- `target` - File, directory, or PR to review
- `options` - Review options (security, performance, all)

## Review Categories

### 1. Security Review
- SQL injection vulnerabilities
- XSS attack vectors
- Authentication/authorization flaws
- Data exposure risks
- Dependency vulnerabilities
- OWASP Top 10 compliance

### 2. Performance Review
- Algorithm efficiency analysis
- Memory leak detection
- Async operation optimization
- Database query optimization
- Bundle size impact
- Rendering performance (UI code)

### 3. Code Quality Review
- SOLID principles adherence
- Design pattern usage
- Code duplication detection
- Naming convention violations
- Function complexity analysis
- Comment quality assessment

### 4. Best Practices Review
- Language-specific idioms
- Framework conventions
- Error handling patterns
- Logging practices
- Configuration management
- Testing patterns

### 5. Architecture Review
- Module coupling analysis
- Interface segregation
- Dependency direction
- Layering violations
- Circular dependencies
- Scalability concerns

## ? PROCESS

1. **Static Analysis**
   - Parse AST and analyze structure
   - Run pattern matching algorithms
   - Check against rule database

2. **Deep Inspection**
   - Trace data flow
   - Analyze control flow
   - Check edge cases
   - Validate assumptions

3. **Scoring**
   - Security score (0-100)
   - Performance score (0-100)
   - Quality score (0-100)
   - Overall rating (A+ to F)

4. **Recommendations**
   - Prioritized fix list
   - Code examples for fixes
   - Refactoring suggestions
   - Learning resources

## ?? OUTPUT Formats

### Summary Report
```
File: src/auth/login.js
Overall Score: B+ (82/100)
- Security: A (95/100)
- Performance: B (78/100)
- Quality: B (80/100)

Critical Issues (1):
1. [Security] Line 45: Missing rate limiting on login endpoint

Warnings (3):
1. [Performance] Line 89: Inefficient array filtering in loop
2. [Quality] Line 23: Function has too many parameters (6)
3. [Practice] Line 112: Missing error handling

Suggestions (5):
...
```

### Detailed Report (Markdown/HTML)
- Issue descriptions with code snippets
- Severity levels and priorities
- Fix code examples
- Learning resources links
- Before/after comparisons

### Inline Comments
- GitHub/GitLab style comments
- Direct placement on code lines
- Ready for PR review

## ?? EXAMPLES

Review a file:
```
/gogeta-ai-code-review src/api/user.js
```

Review with focus on security:
```
/gogeta-ai-code-review src/ --security
```

Review a PR (if integrated):
```
/gogeta-ai-code-review pr:123
```

## Integration

- **Git Hooks**: Pre-commit review
- **CI/CD**: Automated PR reviews
- **IDE**: Real-time review as you type
- **CLI**: On-demand review

## ?? NOTES
- Learns from your codebase patterns
- Customizable rule sets
- Can auto-fix certain issues
- Exports to multiple formats
- Supports all major languages

