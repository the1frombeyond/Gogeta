---
name: GOGETA:ship
description: Create PR, run review, and prepare for merge after verification passes
argument-hint: "[phase number or milestone, e.g., '4' or 'v1.0']"
allowed-tools:
  - Read
  - Bash
  - Grep
  - Glob
  - Write
  - AskUserQuestion
---
## ?? OBJECTIVE
Bridge local completion → merged PR. After /gogeta-verify-work passes, ship the work: push branch, create PR with auto-generated body, optionally trigger review, and track the merge.

Closes the plan → execute → verify → ship loop.


## ?? EXECUTION CONTEXT
@~/.claude/gogeta-cli/workflows/ship.md


Execute the ship workflow from @~/.claude/gogeta-cli/workflows/ship.md end-to-end.


