---
name: GOGETA:session-report
description: Generate a session report with token usage estimates, work summary, and outcomes
allowed-tools:
  - Read
  - Bash
  - Write
---
## ?? OBJECTIVE
Generate a structured SESSION_REPORT.md document capturing session outcomes, work performed, and estimated resource usage. Provides a shareable artifact for post-session review.


## ?? EXECUTION CONTEXT
@~/.claude/gogeta-cli/workflows/session-report.md


## ? PROCESS
Execute the session-report workflow from @~/.claude/gogeta-cli/workflows/session-report.md end-to-end.



