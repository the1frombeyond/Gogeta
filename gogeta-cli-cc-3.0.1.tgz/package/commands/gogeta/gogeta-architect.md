---
description: AI system architect for design and scaling decisions
---

# AI Architect

Intelligent system architecture design and scaling recommendations.

## Usage
```
/gogeta-architect [action] [options]
```

## Actions

### 1. Design System
Generate system architecture from requirements.
```
/gogeta-architect design [description]
```
Example:
```
/gogeta-architect design "E-commerce platform with real-time inventory"
```
Output:
- Architecture diagram (Mermaid)
- Technology stack recommendations
- Component breakdown
- Data flow diagrams
- API structure
- Database schema

### 2. Review Architecture
Analyze current system architecture.
```
/gogeta-architect review [target]
```
Reviews:
- Design pattern adherence
- SOLID principles
- Scalability bottlenecks
- Single points of failure
- Security architecture
- Performance concerns

### 3. Scaling Plan
Generate scaling strategy.
```
/gogeta-architect scaling [target] --users [count]
```
Example:
```
/gogeta-architect scaling . --users 1000000
```
Output:
- Horizontal vs vertical scaling
- Database sharding strategy
- Caching layers
- CDN configuration
- Load balancer setup
- Microservices migration plan

### 4. Tech Stack Advisor
Get technology recommendations.
```
/gogeta-architect tech-stack [requirements]
```
Considers:
- Project size and complexity
- Team expertise
- Performance requirements
- Scalability needs
- Budget constraints
- Time to market

### 5. Migration Planner
Plan system migrations.
```
/gogeta-architect migrate [from] [to]
```
Examples:
- Monolith to microservices
- REST to GraphQL
- SQL to NoSQL
- On-premise to cloud
- Framework upgrades

## Architecture Patterns

### Supported Patterns
- **Microservices**: Service decomposition
- **Event-Driven**: Async event processing
- **Layered Architecture**: Clean separation
- **Hexagonal**: Ports and adapters
- **CQRS**: Command/Query separation
- **Saga**: Distributed transactions
- **Circuit Breaker**: Fault tolerance
- **API Gateway**: Unified entry point

## Output Formats

### Architecture Document
```markdown
# System Architecture: E-Commerce Platform

## Overview
...

## Components
1. User Service
2. Product Catalog
3. Order Management
...

## Data Flow
[Diagram]

## Technology Stack
- Frontend: React + Next.js
- Backend: Node.js + Express
- Database: PostgreSQL + Redis
- Message Queue: RabbitMQ
...

## Scaling Strategy
...
```

### Diagrams Generated
- System context diagram
- Container diagram
- Component diagrams
- Sequence diagrams
- Deployment diagrams
- Data flow diagrams

## Features

### Smart Recommendations
- Based on similar successful systems
- Considers industry best practices
- Accounts for team size and skill
- Balances complexity vs. needs

### Cost Estimation
- Infrastructure cost projections
- Development time estimates
- Maintenance overhead
- Third-party service costs

### Risk Assessment
- identifies architectural risks
- Single points of failure
- Vendor lock-in concerns
- Technical debt implications

## Examples

Design a new system:
```
/gogeta-architect design "Real-time chat app with video calls"
```

Review current architecture:
```
/gogeta-architect review . --detailed
```

Get scaling advice:
```
/gogeta-architect scaling . --users 500000 --budget medium
```

## Notes
- Learns from open-source architectures
- Considers latest technology trends
- Provides multiple design options
- Includes trade-off analysis
- Supports cloud-native design
