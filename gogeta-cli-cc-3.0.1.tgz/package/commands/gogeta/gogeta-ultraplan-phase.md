---
name: GOGETA:ultraplan-phase
description: "[BETA] Offload plan phase to Claude Code's ultraplan cloud — drafts remotely while terminal stays free, review in browser with inline comments, import back via /gogeta-import. Claude Code only."
argument-hint: "[phase-number]"
allowed-tools:
  - Read
  - Bash
  - Glob
  - Grep
---

## ?? OBJECTIVE
Offload GOGETA's plan phase to Claude Code's ultraplan cloud infrastructure.

Ultraplan drafts the plan in a remote cloud session while your terminal stays free.
Review and comment on the plan in your browser, then import it back via /gogeta-import --from.

⚠ BETA: ultraplan is in research preview. Use /gogeta-plan-phase for stable local planning.
Requirements: Claude Code v2.1.91+, claude.ai account, GitHub repository.


## ?? EXECUTION CONTEXT
@~/.claude/gogeta-cli/workflows/ultraplan-phase.md
@~/.claude/gogeta-cli/references/ui-brand.md


## ?? CONTEXT
$ARGUMENTS


## ? PROCESS
Execute the ultraplan-phase workflow end-to-end.



