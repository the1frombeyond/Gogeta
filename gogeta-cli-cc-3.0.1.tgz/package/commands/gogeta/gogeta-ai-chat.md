---
description: Interactive AI coding assistant with context awareness
---

# AI Chat Assistant

Interactive AI coding assistant with full project context awareness.

## ?? USAGE
```
/gogeta-ai-chat [message]
```

## ? FEATURES

### 1. Context-Aware Conversations
- Remembers entire conversation history
- Understands project structure and codebase
- References specific files and functions
- Maintains context across multiple sessions

### 2. Smart Code Assistance
- **Code Explanations**: Understand any code snippet
- **Refactoring Suggestions**: Get improvement ideas
- **Bug Diagnosis**: Describe issues and get solutions
- **Best Practices**: Learn idiomatic patterns
- **Code Review**: Get instant feedback

### 3. Interactive Modes
- **Ask Mode**: Quick questions and answers
- **Explain Mode**: Deep code explanations
- **Pair Program**: Collaborative coding session
- **Learn Mode**: Educational code walkthroughs

## Commands Within Chat

- `/explain [code|file]` - Explain selected code
- `/refactor [target]` - Suggest refactoring
- `/test [target]` - Generate tests
- `/debug [error]` - Help debug issues
- `/optimize [target]` - Performance improvements
- `/docs [target]` - Generate documentation
- `/clear` - Clear conversation history
- `/context` - Show current context
- `/exit` - End chat session

## ?? EXAMPLES

Start a chat session:
```
/gogeta-ai-chat
```

Ask a question directly:
```
/gogeta-ai-chat "How does the authentication middleware work?"
```

Explain code:
```
/gogeta-ai-chat "Explain the code in src/utils/validator.js"
```

## Context Features

- **File References**: `@filename` to reference files
- **Line References**: `@filename:123` for specific lines
- **Function References**: `#functionName` to discuss functions
- **Git Integration**: References to commits, branches, PRs

## ?? OUTPUT Formats

- **Code Blocks**: Syntax-highlighted code
- **Diagrams**: ASCII art and Mermaid diagrams
- **Tables**: Structured data comparison
- **Lists**: Step-by-step instructions

## ?? NOTES
- Maintains separate chat history per project
- Can search codebase during conversation
- Supports multi-turn conversations
- Exports chat logs for reference

