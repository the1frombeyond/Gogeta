---
name: GOGETA:manager
description: Interactive command center for managing multiple phases from one terminal
allowed-tools:
  - Read
  - Write
  - Bash
  - Glob
  - Grep
  - AskUserQuestion
  - Skill
  - Task
---
## ?? OBJECTIVE
Single-terminal command center for managing a milestone. Shows a dashboard of all phases with visual status indicators, recommends optimal next actions, and dispatches work — discuss runs inline, plan/execute run as background agents.

Designed for power users who want to parallelize work across phases from one terminal: discuss a phase while another plans or executes in the background.

**Creates/Updates:**
- No files created directly — dispatches to existing GOGETA commands via Skill() and background Task agents.
- Reads `.planning/STATE.md`, `.planning/ROADMAP.md`, phase directories for status.

**After:** User exits when done managing, or all phases complete and milestone lifecycle is suggested.


## ?? EXECUTION CONTEXT
@~/.claude/gogeta-cli/workflows/manager.md
@~/.claude/gogeta-cli/references/ui-brand.md


## ?? CONTEXT
No arguments required. Requires an active milestone with ROADMAP.md and STATE.md.

Project context, phase list, dependencies, and recommendations are resolved inside the workflow using `gogeta-sdk query init.manager`. No upfront context loading needed.


## ? PROCESS
Execute the manager workflow from @~/.claude/gogeta-cli/workflows/manager.md end-to-end.
Maintain the dashboard refresh loop until the user exits or all phases complete.



