---
name: GOGETA:plant-seed
description: Capture a forward-looking idea with trigger conditions — surfaces automatically at the right milestone
argument-hint: "[idea summary]"
allowed-tools:
  - Read
  - Write
  - Edit
  - Bash
  - AskUserQuestion
---

## ?? OBJECTIVE
Capture an idea that's too big for now but should surface automatically when the right
milestone arrives. Seeds solve context rot: instead of a one-liner in Deferred that nobody
reads, a seed preserves the full WHY, WHEN to surface, and breadcrumbs to details.

Creates: .planning/seeds/SEED-NNN-slug.md
Consumed by: /gogeta-new-milestone (scans seeds and presents matches)


## ?? EXECUTION CONTEXT
@~/.claude/gogeta-cli/workflows/plant-seed.md


## ? PROCESS
Execute the plant-seed workflow from @~/.claude/gogeta-cli/workflows/plant-seed.md end-to-end.



