---
name: GOGETA:new-milestone
description: Start a new milestone cycle — update PROJECT.md and route to requirements
argument-hint: "[milestone name, e.g., 'v1.1 Notifications']"
allowed-tools:
  - Read
  - Write
  - Bash
  - Task
  - AskUserQuestion
---
## ?? OBJECTIVE
Start a new milestone: questioning → research (optional) → requirements → roadmap.

Brownfield equivalent of new-project. Project exists, PROJECT.md has history. Gathers "what's next", updates PROJECT.md, then runs requirements → roadmap cycle.

**Creates/Updates:**
- `.planning/PROJECT.md` — updated with new milestone goals
- `.planning/research/` — domain research (optional, NEW features only)
- `.planning/REQUIREMENTS.md` — scoped requirements for this milestone
- `.planning/ROADMAP.md` — phase structure (continues numbering)
- `.planning/STATE.md` — reset for new milestone

**After:** `/gogeta-plan-phase [N]` to start execution.


## ?? EXECUTION CONTEXT
@~/.claude/gogeta-cli/workflows/new-milestone.md
@~/.claude/gogeta-cli/references/questioning.md
@~/.claude/gogeta-cli/references/ui-brand.md
@~/.claude/gogeta-cli/templates/project.md
@~/.claude/gogeta-cli/templates/requirements.md


## ?? CONTEXT
Milestone name: $ARGUMENTS (optional - will prompt if not provided)

Project and milestone context files are resolved inside the workflow (`init new-milestone`) and delegated via `<files_to_read>` blocks where subagents are used.


## ? PROCESS
Execute the new-milestone workflow from @~/.claude/gogeta-cli/workflows/new-milestone.md end-to-end.
Preserve all workflow gates (validation, questioning, research, requirements, roadmap approval, commits).



