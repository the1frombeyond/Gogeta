---
name: GOGETA:set-profile
description: Switch model profile for GOGETA agents (quality/balanced/budget/inherit)
argument-hint: <profile (quality|balanced|budget|inherit)>
model: haiku
allowed-tools:
  - Bash
---

Show the following output to the user verbatim, with no extra commentary:

!`if ! command -v gogeta-sdk >/dev/null 2>&1; then printf '⚠ gogeta-sdk not found in PATH — /gogeta-set-profile requires it.\n\nInstall the GOGETA SDK:\n  npm install -g @gogeta-build/sdk\n\nOr update GOGETA to get the latest packages:\n  /gogeta-update\n'; exit 1; fi; gogeta-sdk query config-set-model-profile $ARGUMENTS --raw`
