---
name: GOGETA:add-phase
description: Add phase to end of current milestone in roadmap
argument-hint: <description>
allowed-tools:
  - Read
  - Write
  - Bash
---

## ?? OBJECTIVE
Add a new integer phase to the end of the current milestone in the roadmap.

### ?? Trigger
- Phase number calculation (next sequential integer)
- Directory creation with slug generation
- Roadmap structure updates
- STATE.md roadmap evolution tracking


## ?? EXECUTION CONTEXT
@~/.claude/gogeta-cli/workflows/add-phase.md


## ?? CONTEXT
Arguments: $ARGUMENTS (phase description)

Roadmap and state are resolved in-workflow via `init phase-op` and targeted tool calls.


## ? PROCESS
**Follow the add-phase workflow** from `@~/.claude/gogeta-cli/workflows/add-phase.md`.

The workflow handles all logic including:
1. Argument parsing and validation
2. Roadmap existence checking
3. Current milestone identification
4. Next phase number calculation (ignoring decimals)
5. Slug generation from description
6. Phase directory creation
7. Roadmap entry insertion
8. STATE.md updates



