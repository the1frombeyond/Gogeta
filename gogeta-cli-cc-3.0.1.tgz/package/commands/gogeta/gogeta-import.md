---
name: GOGETA:import
description: Ingest external plans with conflict detection against project decisions before writing anything.
argument-hint: "--from <filepath>"
allowed-tools:
  - Read
  - Write
  - Edit
  - Bash
  - Glob
  - Grep
  - AskUserQuestion
  - Task
---

## ?? OBJECTIVE
Import external plan files into the GOGETA planning system with conflict detection against PROJECT.md decisions.

- **--from**: Import an external plan file, detect conflicts, write as GOGETA PLAN.md, validate via gogeta-plan-checker.

Future: `--prd` mode for PRD extraction is planned for a follow-up PR.


## ?? EXECUTION CONTEXT
@~/.claude/gogeta-cli/workflows/import.md
@~/.claude/gogeta-cli/references/ui-brand.md
@~/.claude/gogeta-cli/references/gate-prompts.md
@~/.claude/gogeta-cli/references/doc-conflict-engine.md


## ?? CONTEXT
$ARGUMENTS


## ? PROCESS
Execute the import workflow end-to-end.



