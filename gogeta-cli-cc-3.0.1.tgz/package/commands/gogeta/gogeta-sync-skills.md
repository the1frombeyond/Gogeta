---
name: GOGETA:sync-skills
description: Sync managed GOGETA skills across runtime roots so multi-runtime users stay aligned after an update
allowed-tools:
  - Bash
  - AskUserQuestion
---

## ?? OBJECTIVE
Sync managed `gogeta-*` skill directories from one canonical runtime's skills root to one or more destination runtime skills roots.

### ?? Trigger
- Argument parsing (--from, --to, --dry-run, --apply)
- Runtime skills root resolution via install.js --skills-root
- Diff computation (CREATE / UPDATE / REMOVE per destination)
- Dry-run reporting (default — no writes)
- Apply execution (copy and remove with idempotency)
- Non-GOGETA skill preservation (only gogeta-* dirs are touched)


