---
name: GOGETA:eval-review
description: Retroactively audit an executed AI phase's evaluation coverage — scores each eval dimension as COVERED/PARTIAL/MISSING and produces an actionable EVAL-REVIEW.md with remediation plan
argument-hint: "[phase number]"
allowed-tools:
  - Read
  - Write
  - Bash
  - Glob
  - Grep
  - Task
  - AskUserQuestion
---
## ?? OBJECTIVE
Conduct a retroactive evaluation coverage audit of a completed AI phase.
Checks whether the evaluation strategy from AI-SPEC.md was implemented.
Produces EVAL-REVIEW.md with score, verdict, gaps, and remediation plan.


## ?? EXECUTION CONTEXT
@~/.claude/gogeta-cli/workflows/eval-review.md
@~/.claude/gogeta-cli/references/ai-evals.md


## ?? CONTEXT
Phase: $ARGUMENTS — optional, defaults to last completed phase.


## ? PROCESS
Execute @~/.claude/gogeta-cli/workflows/eval-review.md end-to-end.
Preserve all workflow gates.



