---
name: GOGETA:fast
description: Execute a trivial task inline — no subagents, no planning overhead
argument-hint: "[task description]"
allowed-tools:
  - Read
  - Write
  - Edit
  - Bash
  - Grep
  - Glob
---

## ?? OBJECTIVE
Execute a trivial task directly in the current context without spawning subagents
or generating PLAN.md files. For tasks too small to justify planning overhead:
typo fixes, config changes, small refactors, forgotten commits, simple additions.

This is NOT a replacement for /gogeta-quick — use /gogeta-quick for anything that
needs research, multi-step planning, or verification. /gogeta-fast is for tasks
you could describe in one sentence and execute in under 2 minutes.


## ?? EXECUTION CONTEXT
@~/.claude/gogeta-cli/workflows/fast.md


## ? PROCESS
Execute the fast workflow from @~/.claude/gogeta-cli/workflows/fast.md end-to-end.



