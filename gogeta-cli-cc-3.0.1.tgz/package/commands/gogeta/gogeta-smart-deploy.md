---
description: AI-powered deployment with optimization and rollback
---

# Smart Deploy

Intelligent deployment automation with AI-powered optimization and safety checks.

## ?? USAGE
```
/gogeta-smart-deploy [action] [target] [options]
```

## ?? ACTIONS

### 1. Analyze Deployment
Analyze current deployment setup.
```
/gogeta-smart-deploy analyze
```
- Reviews deployment configuration
- Checks best practices
- Identifies security issues
- Suggests improvements

### 2. Generate Deployment
Generate deployment configuration.
```
/gogeta-smart-deploy generate [platform]
```
Platforms:
- **Vercel**: Next.js, React, Vue, static sites
- **Netlify**: JAMstack, static sites
- **AWS**: EC2, Lambda, ECS, EKS
- **Azure**: App Service, Functions, AKS
- **GCP**: App Engine, Cloud Run, GKE
- **Docker**: Multi-stage builds, docker-compose
- **Kubernetes**: Manifests, Helm charts
- **Heroku**: Procfile, config vars

### 3. Optimize Deployment
Optimize for performance and cost.
```
/gogeta-smart-deploy optimize
```
- Reduces bundle sizes
- Configures caching strategies
- Sets up CDN
- Optimizes images/assets
- Database query optimization
- Serverless function tuning

### 4. Deploy with Safety
Deploy with automated checks.
```
/gogeta-smart-deploy run [environment]
```
Checks:
- Pre-deployment tests
- Security scan
- Performance budget
- Accessibility check
- SEO validation
- Broken link detection

### 5. Monitor Deployment
Post-deployment monitoring.
```
/gogeta-smart-deploy monitor
```
- Health checks
- Performance metrics
- Error tracking
- User analytics
- Uptime monitoring
- Alert configuration

### 6. Smart Rollback
Intelligent rollback on failures.
```
/gogeta-smart-deploy rollback [version]
```
- Detects deployment failures
- Identifies root cause
- Automatic rollback
- Partial rollback (feature flags)
- Database migration rollback

## ? FEATURES

### Multi-Environment Support
- Development
- Staging
- Production
- Feature branches
- PR previews

### CI/CD Integration
- GitHub Actions
- GitLab CI
- Jenkins
- CircleCI
- Azure DevOps
- Bitbucket Pipelines

### Deployment Strategies
- **Blue-Green**: Zero-downtime switch
- **Canary**: Gradual rollout
- **Rolling**: Sequential updates
- **Feature Flags**: Toggle features
- **A/B Testing**: Compare versions

### Safety Checks
- ✅ All tests pass
- ✅ Security scan clean
- ✅ Performance budget met
- ✅ No broken links
- ✅ Accessibility compliant
- ✅ SEO optimized

## ? PROCESS

1. **Pre-Deployment**
   - Run tests
   - Security scan
   - Build optimization
   - Asset compression
   - Cache invalidation

2. **Deployment**
   - Upload artifacts
   - Database migrations
   - Environment configuration
   - Health checks
   - Smoke tests

3. **Post-Deployment**
   - Verify deployment
   - Run integration tests
   - Monitor metrics
   - Check error rates
   - Validate functionality

## ?? EXAMPLES

Generate Vercel deployment:
```
/gogeta-smart-deploy generate vercel
```

Deploy to production with checks:
```
/gogeta-smart-deploy run production --full-check
```

Monitor deployment:
```
/gogeta-smart-deploy monitor --alerts slack
```

Rollback on failure:
```
/gogeta-smart-deploy rollback --auto-detect
```

## ?? OUTPUT
- Deployment configuration files
- CI/CD pipeline configs
- Optimization report
- Deployment checklist
- Monitoring dashboard
- Rollback plan

## ?? NOTES
- Supports 20+ platforms
- Learns from deployment history
- Improves over time
- Prevents common deployment mistakes
- Saves hours of deployment setup!

