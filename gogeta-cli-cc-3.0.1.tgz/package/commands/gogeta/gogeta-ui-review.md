---
name: GOGETA:ui-review
description: Retroactive 6-pillar visual audit of implemented frontend code
argument-hint: "[phase]"
allowed-tools:
  - Read
  - Write
  - Bash
  - Glob
  - Grep
  - Task
  - AskUserQuestion
---
## ?? OBJECTIVE
Conduct a retroactive 6-pillar visual audit. Produces UI-REVIEW.md with
graded assessment (1-4 per pillar). Works on any project.
Output: {phase_num}-UI-REVIEW.md


## ?? EXECUTION CONTEXT
@~/.claude/gogeta-cli/workflows/ui-review.md
@~/.claude/gogeta-cli/references/ui-brand.md


## ?? CONTEXT
Phase: $ARGUMENTS — optional, defaults to last completed phase.


## ? PROCESS
Execute @~/.claude/gogeta-cli/workflows/ui-review.md end-to-end.
Preserve all workflow gates.



