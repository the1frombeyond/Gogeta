---
description: Automatically generate documentation, API references, and diagrams
---

# Auto-Documentation Generator

Automatically generate comprehensive documentation, API references, and architecture diagrams.

## ?? USAGE
```
/gogeta-auto-doc [target] [options]
```

## ?? PARAMETERS
- `target` - File, directory, or project to document
- `options` - Documentation options (api, readme, diagrams, all)

## ? PROCESS

1. **Code Analysis**
   - Parse source code structure
   - Extract function signatures and types
   - Identify public APIs and interfaces
   - Map dependencies and relationships

2. **Content Generation**
   - **API Documentation**: Generate API references from code
   - **README Files**: Create or update README with usage examples
   - **Architecture Diagrams**: Generate Mermaid/PlantUML diagrams
   - **Inline Documentation**: Add JSDoc/TSDoc/docstrings
   - **Tutorial Content**: Generate getting-started guides

3. **Diagram Types**
   - Class/sequence diagrams
   - Data flow diagrams
   - Architecture overviews
   - Database ER diagrams
   - API endpoint maps

4. **Output Formats**
   - Markdown (default)
   - HTML documentation site
   - PDF documentation
   - Interactive API explorer

## ? FEATURES

- **Smart Comments**: Generate meaningful docstrings
- **Example Generator**: Create usage examples from code
- **Cross-Reference**: Link related functions and modules
- **Version Tracking**: Document changes between versions
- **Multi-language**: Supports JS, TS, Python, Java, Go, Rust

## ?? EXAMPLES

Generate API docs for a module:
```
/gogeta-auto-doc src/api/ --api
```

Generate all documentation:
```
/gogeta-auto-doc . --all
```

Generate architecture diagrams:
```
/gogeta-auto-doc . --diagrams
```

## ?? OUTPUT
- Documentation files in `/docs` or specified directory
- Generated diagrams in Mermaid/PlantUML format
- Updated README with proper sections
- API reference in standard format

