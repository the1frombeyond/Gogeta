---
description: ML-based code quality scoring and improvement suggestions
---

# Code Quality Scoring

ML-based code quality analysis with actionable improvement suggestions.

## ?? USAGE
```
/gogeta-code-quality-score [target] [options]
```

## ?? PARAMETERS
- `target` - File, directory, or project to analyze
- `options` - Scoring options (detailed, fix, report)

## Quality Metrics

1. **Complexity Score** (0-100)
   - Cyclomatic complexity
   - Cognitive complexity
   - Nesting depth analysis

2. **Maintainability Index**
   - Code duplication detection
   - Function length analysis
   - Module coupling assessment

3. **Readability Score**
   - Naming convention adherence
   - Comment quality and coverage
   - Code organization

4. **Performance Score**
   - Algorithm efficiency
   - Memory usage patterns
   - Async operation handling

5. **Security Score**
   - Vulnerability detection
   - Input validation coverage
   - Authentication/authorization checks

6. **Test Coverage**
   - Unit test presence
   - Integration test coverage
   - Edge case handling

## ? PROCESS

1. **Static Analysis**
   - Parse AST and analyze structure
   - Run ML models for pattern detection
   - Compare against best practices database

2. **Scoring**
   - Calculate individual metric scores
   - Generate weighted overall score
   - Benchmark against similar projects

3. **Improvement Suggestions**
   - Prioritized list of improvements
   - Code examples for fixes
   - Refactoring recommendations

4. **Auto-Fix** (with --fix flag)
   - Apply safe automated fixes
   - Format code to standards
   - Remove unused imports/variables

## ?? EXAMPLES

Score a single file:
```
/gogeta-code-quality-score src/utils/helper.js
```

Score entire project with fixes:
```
/gogeta-code-quality-score . --fix --detailed
```

Generate quality report:
```
/gogeta-code-quality-score . --report
```

## ?? OUTPUT
- Overall quality score (0-100)
- Breakdown by metric category
- Prioritized improvement list
- Auto-generated fixes (optional)
- HTML/Markdown report (optional)

