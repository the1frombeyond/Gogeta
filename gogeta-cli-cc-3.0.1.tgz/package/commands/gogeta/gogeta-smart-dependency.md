---
description: AI-powered dependency management and optimization
---

# Smart Dependency Management

Intelligent dependency management with AI-powered analysis and optimization.

## ?? USAGE
```
/gogeta-smart-dependency [action] [options]
```

## ?? ACTIONS

### 1. Analyze Dependencies
Deep analysis of project dependencies.
```
/gogeta-smart-dependency analyze
```
Analyzes:
- Dependency tree and relationships
- Version conflicts and compatibility
- Unused or duplicate packages
- Security vulnerabilities
- License compliance
- Bundle size impact

### 2. Smart Update
Intelligent dependency updates.
```
/gogeta-smart-dependency update [options]
```
Features:
- **Safe Updates**: Only update compatible versions
- **Breaking Detection**: Warns about breaking changes
- **Batch Updates**: Groups related updates
- **Rollback Plan**: Automatic rollback if issues arise

### 3. Optimize Bundle
Reduce bundle size through dependency optimization.
```
/gogeta-smart-dependency optimize
```
- Identifies heavy dependencies
- Suggests lighter alternatives
- Tree-shaking analysis
- Code splitting recommendations
- Lazy loading opportunities

### 4. Security Scan
Check for vulnerable dependencies.
```
/gogeta-smart-dependency security-scan
```
- CVE vulnerability database lookup
- Severity scoring (Critical, High, Medium, Low)
- Fix recommendations
- Automatic patching (with --fix flag)

### 5. Dependency Suggestions
Get AI-powered suggestions for new dependencies.
```
/gogeta-smart-dependency suggest [feature]
```
Example:
```
/gogeta-smart-dependency suggest "add date picker"
```
Output: Suggests popular date picker libraries with pros/cons

### 6. Cleanup
Remove unused dependencies.
```
/gogeta-smart-dependency cleanup
```
- Detects unused packages
- Removes from package.json
- Cleans node_modules
- Updates lock files

## ? FEATURES

### AI Analysis
- **Usage Pattern Detection**: How you actually use each package
- **Alternative Finder**: Better alternatives for your use case
- **Migration Assistant**: Helps migrate between similar packages
- **Version Predictor**: Predicts future version compatibility

### Smart Recommendations
- **Should I use this?**: Evaluates if a dependency is right for you
- **Better alternatives**: Suggests improved packages
- **Deprecation warnings**: Alerts about unmaintained packages
- **Community sentiment**: Analyzes GitHub stars, issues, activity

### Bundle Optimization
- **Size Impact**: Visualize each dependency's size
- **Import Analysis**: What you actually import vs. whole package
- **Tree-shaking**: Which packages support tree-shaking
- **Code Splitting**: Generate split points automatically

## ?? EXAMPLES

Full analysis:
```
/gogeta-smart-dependency analyze
```

Safe update with preview:
```
/gogeta-smart-dependency update --dry-run
```

Apply security fixes:
```
/gogeta-smart-dependency security-scan --fix
```

Get suggestions:
```
/gogeta-smart-dependency suggest "state management"
```

## ?? OUTPUT
- Dependency analysis report (Markdown/HTML)
- Update plan with priorities
- Security vulnerability report
- Bundle size optimization suggestions
- Cleanup recommendations

## ?? NOTES
- Supports npm, yarn, pnpm, bun
- Integrates with package-lock.json, yarn.lock, pnpm-lock.yaml
- Can auto-update package.json and lock files
- Respects semantic versioning rules

