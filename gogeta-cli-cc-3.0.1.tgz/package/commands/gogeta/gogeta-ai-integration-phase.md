---
name: GOGETA:ai-integration-phase
description: Generate AI design contract (AI-SPEC.md) for phases that involve building AI systems — framework selection, implementation guidance from official docs, and evaluation strategy
argument-hint: "[phase number]"
allowed-tools:
  - Read
  - Write
  - Bash
  - Glob
  - Grep
  - Task
  - WebFetch
  - WebSearch
  - AskUserQuestion
  - mcp__context7__*
---
## ?? OBJECTIVE
Create an AI design contract (AI-SPEC.md) for a phase involving AI system development.
Orchestrates gogeta-framework-selector → gogeta-ai-researcher → gogeta-domain-researcher → gogeta-eval-planner.
Flow: Select Framework → Research Docs → Research Domain → Design Eval Strategy → Done


## ?? EXECUTION CONTEXT
@~/.claude/gogeta-cli/workflows/ai-integration-phase.md
@~/.claude/gogeta-cli/references/ai-frameworks.md
@~/.claude/gogeta-cli/references/ai-evals.md


## ?? CONTEXT
Phase number: $ARGUMENTS — optional, auto-detects next unplanned phase if omitted.


## ? PROCESS
Execute @~/.claude/gogeta-cli/workflows/ai-integration-phase.md end-to-end.
Preserve all workflow gates.



