---
name: GOGETA:add-todo
description: Capture idea or task as todo from current conversation context
argument-hint: [optional description]
allowed-tools:
  - Read
  - Write
  - Bash
  - AskUserQuestion
---

## ?? OBJECTIVE
Capture an idea, task, or issue that surfaces during a GOGETA session as a structured todo for later work.

### ?? Trigger
- Directory structure creation
- Content extraction from arguments or conversation
- Area inference from file paths
- Duplicate detection and resolution
- Todo file creation with frontmatter
- STATE.md updates
- Git commits


## ?? EXECUTION CONTEXT
@~/.claude/gogeta-cli/workflows/add-todo.md


## ?? CONTEXT
Arguments: $ARGUMENTS (optional todo description)

State is resolved in-workflow via `init todos` and targeted reads.


## ? PROCESS
**Follow the add-todo workflow** from `@~/.claude/gogeta-cli/workflows/add-todo.md`.

The workflow handles all logic including:
1. Directory ensuring
2. Existing area checking
3. Content extraction (arguments or conversation)
4. Area inference
5. Duplicate checking
6. File creation with slug generation
7. STATE.md updates
8. Git commits



