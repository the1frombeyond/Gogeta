---
description: Real-time multi-developer AI session sharing
---

# Real-Time Collaboration

Share AI coding sessions with your team in real-time.

## ?? USAGE
```
/gogeta-realtime-collab [action]
```

## ?? ACTIONS

### 1. Start Session
Start a collaborative coding session.
```
/gogeta-realtime-collab start [session-name]
```
- Creates a shared session
- Generates invite link
- Syncs AI context across participants

### 2. Join Session
Join ### ?? Trigger session.
```
/gogeta-realtime-collab join <session-id>
```

### 3. Share Context
Share current project context with team.
```
/gogeta-realtime-collab share-context
```
- Shares codebase state
- Shares current roadmap/milestones
- Syncs planning documents

### 4. Collaborative Commands
Run commands together:
```
/gogeta-realtime-collab run <command>
```
- All participants see AI responses
- Can discuss and refine together
- Shared command history

### 5. Session Management
```
/gogeta-realtime-collab list       # List active sessions
/gogeta-realtime-collab leave      # Leave current session
/gogeta-realtime-collab end        # End session (host only)
```

## ? FEATURES

### Live Code Sharing
- See code changes in real-time
- Collaborative editing with conflict resolution
- Shared cursor positions and selections
- Voice chat integration (optional)

### AI Context Sharing
- Shared AI conversation history
- Synchronized project state
- Common understanding of codebase
- Team-wide learning and decisions

### Permissions
- **Host**: Full control, can invite/remove
- **Editor**: Can modify code and run commands
- **Viewer**: Can watch and chat only

## Session Features

- **Chat**: Text chat alongside code
- **Whiteboard**: Shared drawing space for architecture
- **Code Reviews**: Collaborative review sessions
- **Pair Programming**: Driver/navigator roles

## ?? EXAMPLES

Start a session:
```
/gogeta-realtime-collab start "auth-refactor"
```
Output: `Session started! Invite link: https://gogeta.dev/session/abc123`

Join a session:
```
/gogeta-realtime-collab join abc123
```

Share context and run collaborative command:
```
/gogeta-realtime-collab share-context
/gogeta-realtime-collab run "analyze the auth module"
```

## Requirements

- Internet connection for session sharing
- Optional: Microphone for voice chat
- Session host needs GOGETA CLI installed

## ?? NOTES
- Sessions persist for 24 hours by default
- Chat history saved for later reference
- Can record sessions for team learning
- Integrates with Git for shared commits


