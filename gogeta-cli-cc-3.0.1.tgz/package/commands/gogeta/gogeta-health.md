---
name: GOGETA:health
description: Diagnose planning directory health and optionally repair issues
argument-hint: [--repair]
allowed-tools:
  - Read
  - Bash
  - Write
  - AskUserQuestion
---
## ?? OBJECTIVE
Validate `.planning/` directory integrity and report actionable issues. Checks for missing files, invalid configurations, inconsistent state, and orphaned plans.


## ?? EXECUTION CONTEXT
@~/.claude/gogeta-cli/workflows/health.md


## ? PROCESS
Execute the health workflow from @~/.claude/gogeta-cli/workflows/health.md end-to-end.
Parse --repair flag from arguments and pass to workflow.



