---
name: GOGETA:resume-work
description: Resume work from previous session with full context restoration
allowed-tools:
  - Read
  - Bash
  - Write
  - AskUserQuestion
  - SlashCommand
---

## ?? OBJECTIVE
Restore complete project context and resume work seamlessly from previous session.

### ?? Trigger

- STATE.md loading (or reconstruction if missing)
- Checkpoint detection (.continue-here files)
- Incomplete work detection (PLAN without SUMMARY)
- Status presentation
- Context-aware next action routing
  

## ?? EXECUTION CONTEXT
@~/.claude/gogeta-cli/workflows/resume-project.md


## ? PROCESS
**Follow the resume-project workflow** from `@~/.claude/gogeta-cli/workflows/resume-project.md`.

The workflow handles all resumption logic including:

1. Project existence verification
2. STATE.md loading or reconstruction
3. Checkpoint and incomplete work detection
4. Visual status presentation
5. Context-aware option offering (checks CONTEXT.md before suggesting plan vs discuss)
6. Routing to appropriate next command
7. Session continuity updates
   


