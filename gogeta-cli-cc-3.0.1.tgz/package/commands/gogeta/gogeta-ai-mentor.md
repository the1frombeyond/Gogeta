---
description: AI coding mentor with personalized learning paths
---

# AI Mentor

Personalized AI coding mentor that learns your style and teaches you best practices.

## ?? USAGE
```
/gogeta-ai-mentor [action] [topic]
```

## ?? ACTIONS

### 1. Learn
Start a learning session on a topic.
```
/gogeta-ai-mentor learn "React hooks"
```
- Personalized explanations
- Code examples at your skill level
- Interactive exercises
- Progress tracking

### 2. Code Review with Teaching
Get code reviewed with educational insights.
```
/gogeta-ai-mentor review [file]
```
- Explains WHY something is wrong
- Teaches better approaches
- Provides learning resources
- Remembers your common mistakes

### 3. Skill Assessment
Assess your coding skills.
```
/gogeta-ai-mentor assess [language|framework]
```
- Evaluates your code quality
- Identifies knowledge gaps
- Creates learning path
- Tracks improvement over time

### 4. Pair Programming
AI pair programming session.
```
/gogeta-ai-mentor pair [task]
```
- Drives and navigates with you
- Explains decisions in real-time
- Suggests improvements as you code
- Teaches patterns and anti-patterns

### 5. Daily Challenge
Get a coding challenge tailored to your level.
```
/gogeta-ai-mentor challenge
```
- Challenge appropriate to your skill
- Hints if you get stuck
- Multiple solution approaches
- Explains optimal solutions

## Learning Features

### Adaptive Learning
- Adjusts to your skill level
- Focuses on your weak areas
- Recommends next topics
- Remembers your learning style

### Code Analysis
- Detects your coding patterns
- Identifies bad habits
- Suggests improvements
- Tracks progress over time

### Resource Curation
- Recommends articles, videos, courses
- Filters for quality content
- Matches your learning style
- Updates as you progress

### Project-Based Learning
- Suggests projects to build
- Provides guidance as you build
- Reviews your implementation
- Teaches through real projects

## Topics Covered

### Languages
JavaScript, TypeScript, Python, Java, Go, Rust, C#, Ruby, PHP, Swift, Kotlin

### Frameworks
React, Vue, Angular, Next.js, Express, Django, Spring, Rails, Laravel

### Concepts
Design Patterns, Algorithms, Data Structures, Testing, Security, Performance, Architecture

### Tools
Git, Docker, Kubernetes, CI/CD, Webpack, Vite, ESLint, Prettier

## ?? EXAMPLES

Learn a concept:
```
/gogeta-ai-mentor learn "closure in JavaScript"
```

Get mentored code review:
```
/gogeta-ai-mentor review src/components/Login.js
```

Daily challenge:
```
/gogeta-ai-mentor challenge
```

Check learning progress:
```
/gogeta-ai-mentor progress
```

## Personalization

- **Skill Level**: Beginner, Intermediate, Advanced
- **Learning Style**: Visual, Auditory, Kinesthetic (code examples)
- **Pace**: Slow, Normal, Fast
- **Focus Areas**: Frontend, Backend, Fullstack, DevOps, Security

## ?? OUTPUT
- Personalized explanations
- Code examples with comments
- Interactive exercises
- Progress dashboard
- Learning path visualization
- Resource recommendations

## ?? NOTES
- Learns from your interactions
- Remembers your preferences
- Adapts explanations to your level
- Builds on previous knowledge
- Makes learning fun and engaging!

