---
description: AI-suggested code improvements with safety checks
---

# Smart Refactoring

Intelligent code refactoring with safety checks and improvement suggestions.

## ?? USAGE
```
/gogeta-smart-refactor [target] [options]
```

## ?? PARAMETERS
- `target` - File or directory to refactor
- `options` - Refactoring options (dry-run, apply, list)

## Refactoring Patterns

1. **Code Simplification**
   - Extract repeated code into functions
   - Simplify complex conditionals
   - Reduce nesting depth
   - Remove dead code

2. **Performance Optimization**
   - Optimize loops and algorithms
   - Reduce unnecessary computations
   - Improve data structure usage
   - Async/await improvements

3. **Design Pattern Application**
   - Extract interfaces and abstractions
   - Apply SOLID principles
   - Implement appropriate design patterns
   - Improve modularity

4. **Modernization**
   - Update deprecated APIs
   - Use modern language features
   - Migrate to newer frameworks
   - Type safety improvements

5. **Readability Enhancements**
   - Improve variable/function names
   - Add meaningful comments
   - Restructure for clarity
   - Consistent formatting

## Safety Features

- **Pre-refactoring Tests**: Run existing tests before changes
- **Diff Preview**: Show changes before applying
- **Rollback Support**: Easy revert if issues arise
- **Incremental Refactoring**: Apply changes in small steps
- **Impact Analysis**: Check what other code is affected

## ? PROCESS

1. **Analysis**
   - Scan code for refactoring opportunities
   - Identify improvement patterns
   - Check test coverage

2. **Planning**
   - Prioritize refactoring targets
   - Generate refactoring plan
   - Identify dependencies

3. **Execution**
   - Apply refactoring with safety checks
   - Run tests after each change
   - Validate no regressions

4. **Verification**
   - Compare before/after metrics
   - Ensure functionality preserved
   - Update documentation

## ?? EXAMPLES

Dry run to see what would change:
```
/gogeta-smart-refactor src/ --dry-run
```

Apply safe refactorings:
```
/gogeta-smart-refactor src/utils/ --apply
```

List refactoring opportunities:
```
/gogeta-smart-refactor . --list
```

## ?? OUTPUT
- Refactoring plan with priorities
- Code diffs for review
- Applied changes summary
- Improved metrics (complexity, maintainability)
- Updated test results

