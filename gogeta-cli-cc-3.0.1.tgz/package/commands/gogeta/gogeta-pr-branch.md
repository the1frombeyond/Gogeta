---
name: GOGETA:pr-branch
description: Create a clean PR branch by filtering out .planning/ commits — ready for code review
argument-hint: "[target branch, default: main]"
allowed-tools:
  - Bash
  - Read
  - AskUserQuestion
---

## ?? OBJECTIVE
Create a clean branch suitable for pull requests by filtering out .planning/ commits
from the current branch. Reviewers see only code changes, not GOGETA planning artifacts.

This solves the problem of PR diffs being cluttered with PLAN.md, SUMMARY.md, STATE.md
changes that are irrelevant to code review.


## ?? EXECUTION CONTEXT
@~/.claude/gogeta-cli/workflows/pr-branch.md


## ? PROCESS
Execute the pr-branch workflow from @~/.claude/gogeta-cli/workflows/pr-branch.md end-to-end.



