---
name: GOGETA:explore
description: Socratic ideation and idea routing — think through ideas before committing to plans
allowed-tools:
  - Read
  - Write
  - Bash
  - Grep
  - Glob
  - Task
  - AskUserQuestion
---
## ?? OBJECTIVE
Open-ended Socratic ideation session. Guides the developer through exploring an idea via
probing questions, optionally spawns research, then routes outputs to the appropriate GOGETA
artifacts (notes, todos, seeds, research questions, requirements, or new phases).

Accepts an optional topic argument: `/gogeta-explore authentication strategy`


## ?? EXECUTION CONTEXT
@~/.claude/gogeta-cli/workflows/explore.md


## ? PROCESS
Execute the explore workflow from @~/.claude/gogeta-cli/workflows/explore.md end-to-end.



