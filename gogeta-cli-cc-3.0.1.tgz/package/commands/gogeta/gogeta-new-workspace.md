---
name: GOGETA:new-workspace
description: Create an isolated workspace with repo copies and independent .planning/
argument-hint: "--name <name> [--repos repo1,repo2] [--path /target] [--strategy worktree|clone] [--branch name] [--auto]"
allowed-tools:
  - Read
  - Bash
  - Write
  - AskUserQuestion
---
## ?? CONTEXT
**Flags:**
- `--name` (required) — Workspace name
- `--repos` — Comma-separated repo paths or names. If omitted, interactive selection from child git repos in cwd
- `--path` — Target directory. Defaults to `~/gogeta-workspaces/<name>`
- `--strategy` — `worktree` (default, lightweight) or `clone` (fully independent)
- `--branch` — Branch to checkout. Defaults to `workspace/<name>`
- `--auto` — Skip interactive questions, use defaults


## ?? OBJECTIVE
Create a physical workspace directory containing copies of specified git repos (as worktrees or clones) with an independent `.planning/` directory for isolated GOGETA sessions.

**Use cases:**
- Multi-repo orchestration: work on a subset of repos in parallel with isolated GOGETA state
- Feature branch isolation: create a worktree of the current repo with its own `.planning/`

**Creates:**
- `<path>/WORKSPACE.md` — workspace manifest
- `<path>/.planning/` — independent planning directory
- `<path>/<repo>/` — git worktree or clone for each specified repo

**After this command:** `cd` into the workspace and run `/gogeta-new-project` to initialize GOGETA.


## ?? EXECUTION CONTEXT
@~/.claude/gogeta-cli/workflows/new-workspace.md
@~/.claude/gogeta-cli/references/ui-brand.md


## ? PROCESS
Execute the new-workspace workflow from @~/.claude/gogeta-cli/workflows/new-workspace.md end-to-end.
Preserve all workflow gates (validation, approvals, commits, routing).



