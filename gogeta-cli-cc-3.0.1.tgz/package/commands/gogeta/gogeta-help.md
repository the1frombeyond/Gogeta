---
name: GOGETA:help
description: Show available GOGETA commands and usage guide
allowed-tools:
  - Read
---
## ?? OBJECTIVE
Display the complete GOGETA command reference.

Output ONLY the reference content below. Do NOT add:
- Project-specific analysis
- Git status or file context
- Next-step suggestions
- Any commentary beyond the reference


## ?? EXECUTION CONTEXT
@~/.claude/gogeta-cli/workflows/help.md


## ? PROCESS
Output the complete GOGETA command reference from @~/.claude/gogeta-cli/workflows/help.md.
Display the reference content directly — no additions or modifications.



