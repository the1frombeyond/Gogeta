---
name: GOGETA:stats
description: Display project statistics — phases, plans, requirements, git metrics, and timeline
allowed-tools:
  - Read
  - Bash
---
## ?? OBJECTIVE
Display comprehensive project statistics including phase progress, plan execution metrics, requirements completion, git history stats, and project timeline.


## ?? EXECUTION CONTEXT
@~/.claude/gogeta-cli/workflows/stats.md


## ? PROCESS
Execute the stats workflow from @~/.claude/gogeta-cli/workflows/stats.md end-to-end.



