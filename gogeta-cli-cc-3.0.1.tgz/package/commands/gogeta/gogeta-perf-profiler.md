---
description: AI-powered performance profiling and optimization
---

# Performance Profiler

Intelligent performance analysis and optimization recommendations.

## Usage
```
/gogeta-perf-profiler [target] [options]
```

## Parameters
- `target` - Application, file, or endpoint to profile
- `options` - Profiling options (cpu, memory, network, all)

## Profiling Types

### 1. CPU Profiling
- Function-level CPU usage
- Hot path identification
- Algorithm complexity analysis
- Loop optimization opportunities
- Recursive call analysis

### 2. Memory Profiling
- Memory leak detection
- Heap usage analysis
- Garbage collection impact
- Object retention analysis
- Memory allocation patterns

### 3. Network Profiling
- API call optimization
- Request/response size analysis
- Caching opportunities
- CDN optimization
- WebSocket efficiency

### 4. Database Profiling
- Slow query identification
- Missing index detection
- N+1 query problems
- Connection pool analysis
- Transaction optimization

### 5. Rendering Profiling (UI)
- Component render time
- DOM update analysis
- Layout thrashing detection
- Animation frame drops
- Bundle loading impact

## Process

1. **Instrumentation**
   - Add profiling hooks
   - Collect performance metrics
   - Trace function calls
   - Monitor resource usage

2. **Analysis**
   - Identify bottlenecks
   - Calculate time complexity
   - Detect anti-patterns
   - Compare with benchmarks

3. **Recommendations**
   - Optimization strategies
   - Code refactoring suggestions
   - Architecture changes
   - Caching strategies
   - Lazy loading opportunities

4. **Verification**
   - Before/after comparison
   - Performance regression testing
   - Load testing validation

## Output

### Performance Report
```
Target: src/api/user-service.js
Overall Performance: 72/100

CPU Analysis:
- Hot function: processUserData() - 340ms (45% of total)
- Complex algorithm: O(n²) sorting at line 89
- Unnecessary recalculation: line 112 (called 50x in loop)

Memory Analysis:
- Potential leak: userCache grows unbounded
- Large object: config at line 23 (2.3MB)
- Unreleased listeners: 5 event emitters

Recommendations (Priority Order):
1. [HIGH] Implement pagination in getUserList() - could reduce memory by 80%
2. [HIGH] Memoize processUserData() result - could save 300ms per call
3. [MEDIUM] Add cleanup for userCache - prevent memory leak
4. [LOW] Use virtual scrolling for large lists
```

### Visualization
- Flame graphs (CPU usage)
- Heap snapshots (Memory)
- Timeline view (Async operations)
- Waterfall charts (Network)
- Call graphs (Dependencies)

## Examples

Profile an API endpoint:
```
/gogeta-perf-profiler /api/users --cpu --memory
```

Profile with load testing:
```
/gogeta-perf-profiler . --load-test 100req/sec
```

Profile database queries:
```
/gogeta-perf-profiler db:queries --slow-query-threshold 100ms
```

## Features

- **Real User Metrics (RUM)**: Analyze production performance
- **Synthetic Testing**: Controlled performance tests
- **Comparative Analysis**: Before/after optimization
- **Regression Detection**: Catch performance degradation
- **Smart Baselines**: Learn normal performance patterns

## Integration

- **Development**: Profile during coding
- **CI/CD**: Automated performance gates
- **Monitoring**: Continuous production profiling
- **Alerting**: Performance regression alerts

## Notes
- Supports Node.js, Python, Java, Go, Rust
- Integrates with Chrome DevTools
- Exports to multiple formats (JSON, HTML, PDF)
- Can auto-generate performance tests
