---
description: AI-powered smart debugging with root cause analysis
---

# Smart Debugging Engine

Intelligent debugging that identifies root causes and suggests fixes using AI analysis.

## ?? USAGE
```
/gogeta-smart-debug [error|file|description]
```

## ?? PARAMETERS
- `error` - Error message or stack trace
- `file` - File to analyze for bugs
- `description` - Description of the issue

## ? PROCESS

1. **Error Analysis**
   - Parse error messages and stack traces
   - Identify error patterns and common causes
   - Map to known issues in knowledge base

2. **Code Inspection**
   - Analyze relevant code sections
   - Trace execution paths
   - Identify potential null pointers, race conditions, memory leaks

3. **Root Cause Detection**
   - Determine underlying cause (not just symptoms)
   - Check for logic errors, type mismatches, async issues
   - Validate assumptions in code

4. **Solution Generation**
   - Generate fix recommendations
   - Provide multiple solution approaches
   - Include code patches ready to apply

5. **Verification**
   - Test fix against original error
   - Check for side effects
   - Validate with static analysis

## ? FEATURES

- **StackTrace Parser**: Intelligent parsing of stack traces across languages
- **Pattern Matching**: Recognizes common bug patterns
- **Dependency Analyzer**: Checks for version conflicts and compatibility
- **Performance Profiler**: Identifies performance-related bugs
- **Memory Debugger**: Detects memory leaks and inefficient usage

## ?? EXAMPLES

Debug from error message:
```
/gogeta-smart-debug "TypeError: Cannot read property 'map' of undefined at line 45"
```

Debug a file:
```
/gogeta-smart-debug src/components/UserList.js
```

## ?? OUTPUT
- Root cause analysis report
- Suggested fixes with code
- Prevention recommendations
- Related documentation links

