---
name: GOGETA:secure-phase
description: Retroactively verify threat mitigations for a completed phase
argument-hint: "[phase number]"
allowed-tools:
  - Read
  - Write
  - Edit
  - Bash
  - Glob
  - Grep
  - Task
  - AskUserQuestion
---
## ?? OBJECTIVE
Verify threat mitigations for a completed phase. Three states:
- (A) SECURITY.md exists — audit and verify mitigations
- (B) No SECURITY.md, PLAN.md with threat model exists — run from artifacts
- (C) Phase not executed — exit with guidance

Output: updated SECURITY.md.


## ?? EXECUTION CONTEXT
@~/.claude/gogeta-cli/workflows/secure-phase.md


## ?? CONTEXT
Phase: $ARGUMENTS — optional, defaults to last completed phase.


## ? PROCESS
Execute @~/.claude/gogeta-cli/workflows/secure-phase.md.
Preserve all workflow gates.



