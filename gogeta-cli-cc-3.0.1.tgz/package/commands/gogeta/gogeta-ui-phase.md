---
name: GOGETA:ui-phase
description: Generate UI design contract (UI-SPEC.md) for frontend phases
argument-hint: "[phase]"
allowed-tools:
  - Read
  - Write
  - Bash
  - Glob
  - Grep
  - Task
  - WebFetch
  - AskUserQuestion
  - mcp__context7__*
---
## ?? OBJECTIVE
Create a UI design contract (UI-SPEC.md) for a frontend phase.
Orchestrates gogeta-ui-researcher and gogeta-ui-checker.
Flow: Validate → Research UI → Verify UI-SPEC → Done


## ?? EXECUTION CONTEXT
@~/.claude/gogeta-cli/workflows/ui-phase.md
@~/.claude/gogeta-cli/references/ui-brand.md


## ?? CONTEXT
Phase number: $ARGUMENTS — optional, auto-detects next unplanned phase if omitted.


## ? PROCESS
Execute @~/.claude/gogeta-cli/workflows/ui-phase.md end-to-end.
Preserve all workflow gates.



