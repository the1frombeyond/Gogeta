---
description: AI-powered git operations, commit messages, and merge conflict resolution
---

# Git Intelligence

AI-powered Git assistance for smarter version control operations.

## ?? USAGE
```
/gogeta-git-intelligence [action] [options]
```

## ?? ACTIONS

### 1. Smart Commit
Generate meaningful commit messages from staged changes.
```
/gogeta-git-intelligence commit
```
- Analyzes diff to understand changes
- Generates conventional commit messages
- Includes relevant context and reasoning
- Supports multiple languages

### 2. PR Description
Generate comprehensive pull request descriptions.
```
/gogeta-git-intelligence pr-desc
```
- Summarizes all changes in PR
- Links to related issues
- Suggests reviewers
- Generates changelog entries

### 3. Merge Conflict Resolution
AI-assisted merge conflict resolution.
```
/gogeta-git-intelligence resolve-conflicts
```
- Analyzes conflicting changes
- Suggests intelligent merge strategy
- Preserves intent of both changes
- Validates merged code

### 4. Branch Analysis
Smart branch management and analysis.
```
/gogeta-git-intelligence branch-analysis
```
- Identifies stale branches
- Suggests branch cleanup
- Analyzes branch dependencies
- Recommends merge strategy

### 5. Code Review Assistant
AI-powered code review for PRs.
```
/gogeta-git-intelligence review
```
- Reviews code changes
- Suggests improvements
- Checks for common issues
- Generates review comments

### 6. Smart Rebase
Intelligent rebase with conflict prevention.
```
/gogeta-git-intelligence smart-rebase [target]
```
- Analyzes commit history
- Suggests rebase strategy
- Handles conflicts automatically
- Preserves commit semantics

## ? FEATURES

- **Conventional Commits**: Generates standardized commit messages
- **Diff Analysis**: Deep understanding of code changes
- **Context Awareness**: Considers project history and patterns
- **Multi-language**: Works with any programming language
- **Integration**: Works with GitHub, GitLab, Bitbucket

## ?? EXAMPLES

Generate commit message:
```
/gogeta-git-intelligence commit
```
Output: `feat(auth): add OAuth2 login with Google and GitHub providers`

Generate PR description:
```
/gogeta-git-intelligence pr-desc
```

Resolve merge conflicts:
```
/gogeta-git-intelligence resolve-conflicts
```

## ?? OUTPUT
- Generated commit messages
- PR descriptions with sections
- Conflict resolution suggestions
- Branch management recommendations
- Code review comments

