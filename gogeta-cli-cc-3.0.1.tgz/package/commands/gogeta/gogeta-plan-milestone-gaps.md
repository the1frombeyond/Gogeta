---
name: GOGETA:plan-milestone-gaps
description: Create phases to close all gaps identified by milestone audit
allowed-tools:
  - Read
  - Write
  - Bash
  - Glob
  - Grep
  - AskUserQuestion
---
## ?? OBJECTIVE
Create all phases necessary to close gaps identified by `/gogeta-audit-milestone`.

Reads MILESTONE-AUDIT.md, groups gaps into logical phases, creates phase entries in ROADMAP.md, and offers to plan each phase.

One command creates all fix phases — no manual `/gogeta-add-phase` per gap.


## ?? EXECUTION CONTEXT
@~/.claude/gogeta-cli/workflows/plan-milestone-gaps.md


## ?? CONTEXT
**Audit results:**
Glob: .planning/v*-MILESTONE-AUDIT.md (use most recent)

Original intent and current planning state are loaded on demand inside the workflow.


## ? PROCESS
Execute the plan-milestone-gaps workflow from @~/.claude/gogeta-cli/workflows/plan-milestone-gaps.md end-to-end.
Preserve all workflow gates (audit loading, prioritization, phase grouping, user confirmation, roadmap updates).



