---
name: GOGETA:cleanup
description: Archive accumulated phase directories from completed milestones
allowed-tools:
  - Read
  - Write
  - Bash
  - AskUserQuestion
---
## ?? OBJECTIVE
Archive phase directories from completed milestones into `.planning/milestones/v{X.Y}-phases/`.

Use when `.planning/phases/` has accumulated directories from past milestones.


## ?? EXECUTION CONTEXT
@~/.claude/gogeta-cli/workflows/cleanup.md


## ? PROCESS
Follow the cleanup workflow at @~/.claude/gogeta-cli/workflows/cleanup.md.
Identify completed milestones, show a dry-run summary, and archive on confirmation.



